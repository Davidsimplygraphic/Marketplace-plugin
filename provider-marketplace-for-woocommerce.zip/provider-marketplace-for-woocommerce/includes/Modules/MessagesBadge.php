<?php
namespace SGPM\Modules;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

/**
 * MessagesBadge (text "Workrooms" everywhere)
 * - Renders "Workrooms" + unread badge in My Account nav, header dropdown, and shortcode.
 * - Shortcode: [sgpm_messages_badge] (linked text + badge) or link="no"
 * - Polls unread count via AJAX every 30s.
 */
class MessagesBadge {

    public static function init(): void {
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_action('wp_ajax_sgpm_unread_count', [__CLASS__, 'ajax_count']);
        add_action('wp_ajax_nopriv_sgpm_unread_count', [__CLASS__, 'ajax_count_public']);
        add_shortcode('sgpm_messages_badge', [__CLASS__, 'shortcode']);
    }

    /* ---------- Shortcode ----------
     * [sgpm_messages_badge link="yes|no" label="Workrooms" class=""]
     */
    public static function shortcode($atts): string {
        $atts = shortcode_atts([
            'link'  => 'yes',
            'label' => 'Workrooms',
            'class' => '',
        ], $atts, 'sgpm_messages_badge');

        $uid   = get_current_user_id();
        $count = $uid ? self::get_unread_count($uid) : 0;

        $badge_classes = 'sgpm-badge js-msg-badge' . ($count ? '' : ' is-zero');
        $badge = sprintf(
            '<span class="%s" aria-hidden="%s" aria-label="%d unread message%s">%d</span>',
            esc_attr($badge_classes),
            $count ? 'false' : 'true',
            (int) $count,
            $count === 1 ? '' : 's',
            (int) $count
        );

        $wrap_class = 'sgpm-badge-wrap sgpm-msg-inline ' . sanitize_html_class($atts['class']);
        $text_html  = sprintf('<span class="sgpm-msg-text">%s</span>', esc_html($atts['label']));

        if (strtolower($atts['link']) === 'no') {
            return sprintf(
                '<span class="%s" aria-label="%s">%s%s</span>',
                esc_attr($wrap_class),
                esc_attr($atts['label']),
                $text_html,
                $badge
            );
        }

        $myaccount = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : home_url('/my-account/');
        $endpoint  = self::get_messages_endpoint();
        $url       = trailingslashit($myaccount) . trailingslashit($endpoint);

        return sprintf(
            '<a class="%s sgpm-msg-link" href="%s" aria-label="%s">%s%s</a>',
            esc_attr($wrap_class),
            esc_url($url),
            esc_attr($atts['label']),
            $text_html,
            $badge
        );
    }

    /* ---------- AJAX ---------- */
    public static function ajax_count(): void {
        $uid = get_current_user_id();
        $count = $uid ? self::get_unread_count($uid) : 0;
        wp_send_json_success(['count' => (int) $count]);
    }
    public static function ajax_count_public(): void {
        wp_send_json_success(['count' => 0]);
    }

    /* ---------- Assets (CSS + JS) ---------- */
    public static function enqueue_assets(): void {
        if (is_admin()) return;

        // CSS
        wp_register_style('sgpm-messages-badge-style', false);
        wp_enqueue_style('sgpm-messages-badge-style');
        $css = '
        .sgpm-badge {
            display:inline-flex; align-items:center; justify-content:center;
            min-width:1.25em; height:1.25em; padding:0 .4em; border-radius:999px;
            font-size:12px; line-height:1; font-weight:700; color:#fff;
            background:#e20; margin-left:.45em; vertical-align:middle;
        }
        .sgpm-badge.is-zero { display:none; }
        .sgpm-badge-wrap { position:relative; display:inline-flex; align-items:center; gap:.45em; }
        .sgpm-msg-text { display:inline-block; }
        .site-header .sgpm-badge { background:#25D366; } /* optional: green in header */
        ';
        wp_add_inline_style('sgpm-messages-badge-style', $css);

        // JS (quotes are crafted to avoid PHP parse issues)
        wp_register_script('sgpm-messages-badge-js', false, ['jquery'], '1.0.5', true);
        wp_enqueue_script('sgpm-messages-badge-js');

        $endpoint = wp_json_encode(self::get_messages_endpoint());
        $ajax     = wp_json_encode(admin_url('admin-ajax.php'));
        $label    = wp_json_encode('Workrooms');

        $js = '(function($){'
            .'var endpoint='.$endpoint.', ajaxUrl='.$ajax.', labelTxt='.$label.';'
            .'function runEnhance(){'
                // My Account side nav link
                .'var sel1=".woocommerce-MyAccount-navigation-link--"+endpoint+" a";'
                // Any other link to /my-account/{endpoint}/ (e.g., header dropdown)
                .'var sel2="a[href*=\'/my-account/"+endpoint+"/\']";'
                .'$(sel1+","+sel2).each(function(){'
                    .'var $a=$(this);'
                    .'if(!$a.hasClass("sgpm-msg-link")){'
                        .'$a.addClass("sgpm-msg-link").attr("aria-label",labelTxt);'
                        .'$a.empty()'
                          .'.append($("<span>",{"class":"sgpm-msg-text",text:labelTxt}))'
                          .'.append($("<span>",{"class":"sgpm-badge js-msg-badge is-zero","aria-hidden":"true","aria-label":"0 unread messages"}));'
                    .'}else if(!$a.find(".js-msg-badge").length){'
                        .'$a.append("<span class=\"sgpm-badge js-msg-badge is-zero\" aria-hidden=\"true\" aria-label=\"0 unread messages\"></span>");'
                    .'}'
                .'});'
            .'}'
            .'function refreshBadge(){'
                .'$.post(ajaxUrl,{action:"sgpm_unread_count"},function(res){'
                    .'if(!res||!res.success)return;'
                    .'var c=parseInt(res.data.count,10)||0;'
                    .'$(".js-msg-badge").each(function(){'
                        .'var $b=$(this);'
                        .'if(c>0){'
                            .'$b.text(c).removeClass("is-zero").attr({"aria-hidden":"false","aria-label":c+" unread message"+(c===1?"":"s")});'
                        .'}else{'
                            .'$b.text("").addClass("is-zero").attr({"aria-hidden":"true","aria-label":"0 unread messages"});'
                        .'}'
                    .'});'
                .'});'
            .'}'
            .'$(document).ready(function(){runEnhance();refreshBadge();setInterval(refreshBadge,30000);});'
            .'setTimeout(runEnhance,1000);'
        .'})(jQuery);';

        wp_add_inline_script('sgpm-messages-badge-js', $js);
    }

    /* ---------- Helpers ---------- */
    private static function get_messages_endpoint(): string {
        $default = 'messages';
        if (defined('SGPM\\Constants::EP_MESSAGES')) {
            $default = Constants::EP_MESSAGES;
        }
        return apply_filters('sgpm_messages_endpoint', $default);
    }

    /** Count unread messages (override via filter `sgpm/unread_messages_count`) */
    public static function get_unread_count(int $user_id): int {
        $user_id = absint($user_id);
        if (!$user_id) return 0;

        $args = [
            'post_type'              => 'sgpm_message',
            'post_status'            => ['publish', 'private'],
            'fields'                 => 'ids',
            'posts_per_page'         => -1,
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
            'meta_query'             => [
                'relation' => 'AND',
                [
                    'key'     => '_recipient',
                    'value'   => $user_id,
                    'compare' => '='
                ],
                [
                    'relation' => 'OR',
                    ['key' => '_read', 'compare' => 'NOT EXISTS'],
                    ['key' => '_read', 'value' => '1', 'compare' => '!=']
                ]
            ],
        ];

        $posts = get_posts($args);
        $count = is_array($posts) ? count($posts) : 0;
        return (int) apply_filters('sgpm/unread_messages_count', $count, $user_id);
    }
}
