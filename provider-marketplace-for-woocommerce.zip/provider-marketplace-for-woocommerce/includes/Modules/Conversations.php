<?php
namespace SGPM\Modules;

use SGPM\Constants;
use SGPM\Helpers;

if (!defined('ABSPATH')) exit;

class Conversations {
  public static function init(): void {
    add_action('init', [__CLASS__, 'register_cpt']);
    add_action('woocommerce_order_status_processing', [__CLASS__, 'maybe_create_for_order']);
    add_action('woocommerce_order_status_completed',  [__CLASS__, 'maybe_create_for_order']); // safety if gateway skips processing
  }

  public static function register_cpt(): void {
    register_post_type(Constants::CPT_CONVO, [
      'labels' => ['name'=>'Workrooms','singular_name'=>'Workroom'],
      'public' => false, 'show_ui' => true, 'show_in_menu' => 'edit.php?post_type='.Constants::CPT_PROFILE,
      'supports' => ['title'],
      'capability_type' => 'post', 'map_meta_cap' => true,
    ]);
  }

  public static function maybe_create_for_order($order_id): void {
    $order = wc_get_order($order_id);
    if (!$order) return;

    foreach ($order->get_items('line_item') as $item_id => $item) {
      $provider_id = (int)$item->get_meta('_provider_user_id', true);
      if (!$provider_id) continue;

      // Set default payout status to pending on first touch
      if (!$item->get_meta('_provider_payout_status', true)) {
        $item->add_meta_data('_provider_payout_status', Constants::PSTATUS_PENDING, true);
        $item->save();
      }

      // Ensure a workroom exists
      $convo_id = (int)$item->get_meta('_sgpm_convo_id', true);
      if ($convo_id && get_post($convo_id)) continue;

      $customer_id = (int)$order->get_user_id();
      $title = sprintf('Workroom: Order #%d • Item %s', $order->get_id(), $item->get_name());

      $convo_id = wp_insert_post([
        'post_type'   => Constants::CPT_CONVO,
        'post_status' => 'publish',
        'post_title'  => $title,
        'meta_input'  => [
          '_order_id'      => $order->get_id(),
          '_order_item_id' => $item_id,
          '_provider_id'   => $provider_id,
          '_customer_id'   => $customer_id,
          '_job_status'    => 'open', // open|submitted|completed|disputed
        ],
      ]);

      if ($convo_id) {
        $item->add_meta_data('_sgpm_convo_id', $convo_id, true);
        $item->save();

        // Notify both parties
        self::notify_parties($provider_id, $customer_id, 'Workroom opened',
          sprintf('A workroom has been opened for your order item: %s', $item->get_name()));
      }
    }
  }

  public static function get_convos_for_user($user_id): array {
    return get_posts([
      'post_type' => Constants::CPT_CONVO,
      'post_status' => 'publish',
      'posts_per_page' => 50,
      'meta_query' => [
        'relation' => 'OR',
        ['key'=>'_provider_id','value'=>$user_id,'compare'=>'='],
        ['key'=>'_customer_id','value'=>$user_id,'compare'=>'='],
      ],
      'orderby' => 'ID',
      'order' => 'DESC',
    ]);
  }

  public static function user_can_access($convo_id, $user_id): bool {
    $p = get_post($convo_id);
    if (!$p) return false;
    $pid = (int)get_post_meta($convo_id, '_provider_id', true);
    $cid = (int)get_post_meta($convo_id, '_customer_id', true);
    return current_user_can('manage_woocommerce') || $user_id === $pid || $user_id === $cid;
  }

  public static function add_message($convo_id, $author_id, string $content, array $files=[]): int {
    $comment_id = wp_insert_comment([
      'comment_post_ID' => $convo_id,
      'user_id'         => $author_id,
      'comment_content' => wp_kses_post($content),
      'comment_type'    => 'sgpm_msg',
      'comment_approved'=> 1,
    ]);
    if ($comment_id && $files) {
      foreach ($files as $file) {
        $aid = Helpers::handle_file_upload($file, $author_id, 'Workroom attachment');
        if ($aid) add_comment_meta($comment_id, '_sgpm_attachment_id', $aid);
      }
    }
    return (int)$comment_id;
  }

  public static function get_messages($convo_id): array {
    return get_comments([
      'post_id' => $convo_id,
      'type'    => 'sgpm_msg',
      'status'  => 'approve',
      'orderby' => 'comment_ID',
      'order'   => 'ASC',
    ]);
  }

  private static function notify_parties($provider_id, $customer_id, $subject, $body): void {
    $p = get_userdata($provider_id);
    $c = get_userdata($customer_id);
    $emails = array_filter([$p->user_email ?? '', $c->user_email ?? '']);
    foreach ($emails as $to) wp_mail($to, $subject, $body);
  }
}