<?php
namespace SGPM\Modules;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

class Avatar {
    public function init(): void {
        add_filter('get_avatar_url', [$this, 'override_avatar_url'], 10, 3);
    }

    /**
     * Prefer a custom uploaded avatar (user meta sgpm_avatar_id) over Gravatar.
     * Handles all get_avatar_id input variants: user ID, WP_User, objects with ->user_id, or email string.
     */
    public function override_avatar_url($url, $id_or_email, $args) {
        $user = null;

        // WP_User object
        if ($id_or_email instanceof \WP_User) {
            $user = $id_or_email;

        // Numeric user ID
        } elseif (is_numeric($id_or_email)) {
            $user = get_user_by('id', (int) $id_or_email);

        // Objects that carry a ->user_id (e.g., WP_Comment)
        } elseif (is_object($id_or_email) && isset($id_or_email->user_id)) {
            $user = get_user_by('id', (int) $id_or_email->user_id);

        // Email string
        } elseif (is_string($id_or_email) && function_exists('is_email') && is_email($id_or_email)) {
            $user = get_user_by('email', $id_or_email);
        }

        if ($user instanceof \WP_User) {
            $avatar_id = (int) get_user_meta($user->ID, Constants::META_AVATAR_ID, true);
            if ($avatar_id) {
                // Respect requested size when possible; default to 'thumbnail'
                $size = (is_array($args) && isset($args['size'])) ? $args['size'] : 'thumbnail';
                if (is_numeric($size)) {
                    // wp_get_attachment_image_url accepts an array for exact dimensions
                    $size = [ (int) $size, (int) $size ];
                }
                $custom = wp_get_attachment_image_url($avatar_id, $size);
                if ($custom) return $custom;
            }
        }

        // Fallback to original URL (Gravatar / default)
        return $url;
    }
}
