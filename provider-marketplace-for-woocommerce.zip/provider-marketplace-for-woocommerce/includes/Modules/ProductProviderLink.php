<?php
namespace SGPM\Modules;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

class ProductProviderLink {
    public static function init(): void {
        // Flatsome prints share icons around priority ~50.
        // Hook at 60 to render AFTER the share row.
        add_action('woocommerce_single_product_summary', [__CLASS__, 'output'], 60);
    }

    public static function output(): void {
        static $printed = false;
        if ($printed) return;

        if (!function_exists('is_product') || !is_product()) return;
        global $product;
        if (!$product) return;

        $product_id = $product->get_id();
        $author_id  = (int) get_post_field('post_author', $product_id);
        if (!$author_id) return;

        // Only show for Providers (adjust if you want it for all authors)
        $user = get_user_by('id', $author_id);
        if (!$user || !in_array(Constants::ROLE, (array) $user->roles, true)) return;

        $name = $user->display_name ?: $user->user_login;

        // Try to find the Provider Profile CPT authored by this user
        $profile_id = 0;
        $ids = get_posts([
            'post_type'        => Constants::CPT_PROFILE,
            'post_status'      => 'publish',
            'author'           => $author_id,
            'numberposts'      => 1,
            'orderby'          => 'date',
            'order'            => 'DESC',
            'fields'           => 'ids',
            'suppress_filters' => true,
        ]);
        if ($ids) $profile_id = (int) $ids[0];

        // Fallback: author archive if no profile post exists
        $url = $profile_id ? get_permalink($profile_id) : get_author_posts_url($author_id);

        echo '<div class="sgpm-provider-meta" style="margin-top:10px;display:flex;align-items:center;gap:.5rem;">'
           . get_avatar($author_id, 28)
           . '<span>'
           . esc_html__('Provided by:', 'provider-marketplace') . ' '
           . '<a href="' . esc_url($url) . '" rel="author" target="_blank" class="sgpm-provider-link">' . esc_html($name) . '</a>'
           . '</span></div>';

        $printed = true;
    }
}