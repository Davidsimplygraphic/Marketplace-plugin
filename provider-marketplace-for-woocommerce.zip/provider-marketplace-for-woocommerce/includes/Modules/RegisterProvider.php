<?php
namespace SGPM\Modules\Account;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

class RegisterProvider {

    public static function init(): void {
        add_shortcode('sl_register_provider', [__CLASS__, 'shortcode']);
        add_action('template_redirect', [__CLASS__, 'handle_submit']);
    }

    public static function shortcode($atts = [], $content = null): string {
        ob_start();

        // WooCommerce is required for My Account links / notices
        if (!function_exists('wc_get_page_permalink')) {
            echo '<div class="notice notice-error">WooCommerce is required for this feature.</div>';
            return ob_get_clean();
        }

        // Not logged in → send to My Account (login/register)
        if (!is_user_logged_in()) {
            $account_url = wc_get_page_permalink('myaccount');
            echo '<div class="sl-register-provider not-logged-in">';
            echo '<p>You need an account to apply as a provider.</p>';
            echo '<p><a class="button" href="' . esc_url($account_url) . '">Log in / Register</a></p>';
            echo '</div>';
            return ob_get_clean();
        }

        $u = wp_get_current_user();
        $is_provider = in_array(Constants::ROLE, (array) $u->roles, true);
        $dashboard_url = wc_get_page_permalink('myaccount');

        // Already a provider → just show dashboard button
        if ($is_provider) {
            echo '<div class="sl-register-provider already">';
            echo '<p>You are already a service provider.</p>';
            echo '<p><a class="button buttonnew" href="' . esc_url($dashboard_url) . '">View Dashboard</a></p>';
            echo '</div>';
            return ob_get_clean();
        }

        // Show the registration form
        ?>
        <form method="post" class="sl-register-provider-form">
            <?php wp_nonce_field('sgpm_register_provider', '_wpnonce_sgpm_register_provider'); ?>
            <input type="hidden" name="sgpm_action" value="register_provider">

            <p>Become a verified provider on Soundlab. Click the button below to upgrade your account.</p>

            <p class="form-row">
                <label>
                    <input type="checkbox" name="sgpm_terms" value="1" required>
                    I agree to the marketplace terms.
                </label>
            </p>

            <p class="form-row">
                <button type="submit" class="button primary">Become a Provider</button>
                <a href="<?php echo esc_url($dashboard_url); ?>" class="button buttonnew" style="float:right">View Dashboard</a>
            </p>
        </form>
        <?php

        return ob_get_clean();
    }

    public static function handle_submit(): void {
        if (empty($_POST['sgpm_action']) || $_POST['sgpm_action'] !== 'register_provider') {
            return;
        }
        if (!is_user_logged_in()) {
            return;
        }
        if (!function_exists('wc_add_notice')) {
            return;
        }

        if (!wp_verify_nonce($_POST['_wpnonce_sgpm_register_provider'] ?? '', 'sgpm_register_provider')) {
            wc_add_notice(__('Security check failed. Please try again.', 'provider-marketplace'), 'error');
            return;
        }

        $u = wp_get_current_user();

        // If already provider, just bounce to dashboard
        if (in_array(Constants::ROLE, (array) $u->roles, true)) {
            wc_add_notice(__('You are already a provider.', 'provider-marketplace'), 'notice');
            self::redirect_to_dashboard();
        }

        // Grant provider role
        $u->add_role(Constants::ROLE);

        /**
         * Let other modules react (e.g., Profiles::maybe_create_on_role_change)
         * and create default profile/cards/etc.
         */
        do_action('sgpm_user_became_provider', $u->ID);

        wc_add_notice(__('Welcome onboard! Your provider dashboard is ready.', 'provider-marketplace'), 'success');
        self::redirect_to_dashboard();
    }

    protected static function redirect_to_dashboard(): void {
        if (function_exists('wc_get_page_permalink')) {
            wp_safe_redirect(wc_get_page_permalink('myaccount'));
            exit;
        }
    }
}
