<?php
namespace SGPM\Modules;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

class Profiles {
    public static function activate(): void {
        self::register_cpt();
    }

    public static function init(): void {
        add_action('init', [__CLASS__, 'register_cpt']);
        add_action('user_register', [__CLASS__, 'maybe_create_on_register']);
        add_action('set_user_role', [__CLASS__, 'maybe_create_on_role_change'], 10, 3);
        add_filter('the_content', [__CLASS__, 'inject_content']);
        add_shortcode('sgpm_provider_profile', [__CLASS__, 'shortcode']);
    }

    public static function register_cpt(): void {
        register_post_type(Constants::CPT_PROFILE, [
            'label'        => __('Provider Profiles','provider-marketplace'),
            'labels'       => ['singular_name' => __('Provider Profile','provider-marketplace')],
            'public'       => true,
            'has_archive'  => true,
            'rewrite'      => ['slug' => 'providers', 'with_front' => false],
            'supports'     => ['title','editor','thumbnail'],
            'show_in_rest' => false,
            'menu_position'=> 26,
            'menu_icon'    => 'dashicons-id',
        ]);
    }

    public static function create_profile_for_user(int $user_id): int {
        $user = get_user_by('id', $user_id);
        if (!$user) return 0;

        $existing = (int) get_user_meta($user_id, Constants::META_PROFILE_POST, true);
        if ($existing && get_post($existing)) return $existing;

        $slug = sanitize_title($user->user_nicename ?: $user->display_name);
        $base = $slug; $i = 2;
        while (get_page_by_path($slug, OBJECT, Constants::CPT_PROFILE)) $slug = $base.'-'.$i++;
        $title   = sprintf(__('Provider: %s','provider-marketplace'), $user->display_name);
        $content = '[sgpm_provider_profile user="'.esc_attr($user_id).'"]';

        $post_id = wp_insert_post([
            'post_type'   => Constants::CPT_PROFILE,
            'post_status' => 'publish',
            'post_title'  => $title,
            'post_name'   => $slug,
            'post_content'=> $content,
            'meta_input'  => ['_sgpm_user_id' => $user_id],
        ]);

        if ($post_id && !is_wp_error($post_id)) {
            update_user_meta($user_id, Constants::META_PROFILE_POST, $post_id);
            return (int) $post_id;
        }
        return 0;
    }

    public static function maybe_create_on_register($user_id){
        $user = get_user_by('id', $user_id);
        if ($user && in_array(Constants::ROLE, (array)$user->roles, true)) {
            self::create_profile_for_user($user_id);
        }
    }

    public static function maybe_create_on_role_change($user_id, $new_role, $old_roles){
        if ($new_role === Constants::ROLE) self::create_profile_for_user($user_id);
    }

    public static function inject_content($content){
        if (!is_singular(Constants::CPT_PROFILE)) return $content;
        if (strpos($content, '[sgpm_provider_profile') !== false) return $content;
        $user_id = (int) get_post_meta(get_the_ID(), '_sgpm_user_id', true);
        if ($user_id <= 0) return $content;
        return $content . self::shortcode(['user' => $user_id]);
    }

    /**
     * Render provider profile using Flatsome shortcodes.
     */
    public static function shortcode($atts){
        $atts = shortcode_atts(['user'=>0], $atts, 'sgpm_provider_profile');
        $uid  = (int) $atts['user'];
        if ($uid <= 0) return '';

        // ---- Core user data ----
        $user = get_userdata($uid);
        if (!$user) return '';

        $display    = $user->display_name;
        $first_name = trim((string) get_user_meta($uid, 'first_name', true));
        if (!$first_name) {
            $first_name = trim(strtok($display, ' '));
            if (!$first_name) $first_name = $display;
        }

        $shop = get_user_meta($uid, Constants::META_SHOP_NAME, true);
        $bio  = get_user_meta($uid, Constants::META_BIO, true);
        $name = $shop ?: $display;

        // Avatar: prefer custom headshot (Toolset) if present (ID or URL); fallback to Gravatar
        $headshot_raw = get_user_meta($uid, 'headshot', true);
        $avatar = '';
        if (is_numeric($headshot_raw)) {
            $avatar = wp_get_attachment_image_url((int)$headshot_raw, 'medium') ?: '';
        } elseif (is_string($headshot_raw) && filter_var($headshot_raw, FILTER_VALIDATE_URL)) {
            $avatar = $headshot_raw;
        }
        if (!$avatar) {
            $avatar = get_avatar_url($uid, ['size'=>320]);
        }

        // Possessive: David’s vs James’
        $apos = '’';
        $possessive = rtrim($first_name);
        $possessive .= preg_match('/s$/i', $first_name) ? $apos : $apos.'s';

        // Archive URL for "Back to all"
        $archive_url = get_post_type_archive_link(Constants::CPT_PROFILE);
        if (!$archive_url) $archive_url = home_url('/shop/');

        // ---- Fetch Work Samples ----
        $samples = get_posts([
            'post_type'      => 'attachment',
            'posts_per_page' => 12,
            'post_status'    => 'inherit',
            'author'         => $uid,
            'meta_key'       => Constants::SAMPLE_FLAG_META,
            'meta_value'     => 1,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        // ---- Fetch Services (Woo products) ----
        $products = get_posts([
            'post_type'      => 'product',
            'posts_per_page' => 9,
            'post_status'    => 'publish',
            'author'         => $uid,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        // ---- Build Work Samples markup (3 per row; reveal in batches of 3) ----
        $samples_markup = '';
        if ($samples) {
            foreach ($samples as $att) {
                $is_img = strpos($att->post_mime_type, 'image/') === 0;
                $is_vid = strpos($att->post_mime_type, 'video/') === 0;
                $title  = get_the_title($att->ID);
                $desc   = $att->post_excerpt ?: $att->post_content;
                $desc   = wp_strip_all_tags($desc);

                $samples_markup .= '[col span="4" span__sm="12" class="ws-item"]' . "\n";
                if ($is_img) {
                    // Flatsome image box with attachment ID
                    $samples_markup .= '[ux_image_box img="'.intval($att->ID).'" image_height="70%" image_size="large" text_align="left" text_padding="1rem 1rem 1rem 1rem"]'."\n";
                    if (!empty($desc)) {
                        $samples_markup .= '<p class="uploadtext">'.esc_html($desc).'</p>'."\n";
                    }
                    $samples_markup .= '[/ux_image_box]'."\n";
                } elseif ($is_vid) {
                    // WP video player inside ux_html to avoid shortcode escaping
                    $video_html = wp_video_shortcode([
                        'src'      => wp_get_attachment_url($att->ID),
                        'preload'  => 'metadata',
                        'width'    => 720,
                        'height'   => 405,
                    ]);
                    $samples_markup .= '[ux_html]'."\n";
                    $samples_markup .= '<div class="ws-card">';
                    $samples_markup .= '<div class="ws-media" style="aspect-ratio:16/9;overflow:hidden;background:#fff">'.$video_html.'</div>';
                    $samples_markup .= '<div class="ws-copy" style="padding:12px 6px 0">';
                    if (!empty($desc)) {
                        $samples_markup .= '<p class="uploadtext" style="margin:0">'.esc_html($desc).'</p>';
                    }
                    $samples_markup .= '</div></div>'."\n";
                    $samples_markup .= '[/ux_html]'."\n";
                } else {
                    // Other types: simple link card
                    $url = wp_get_attachment_url($att->ID);
                    $samples_markup .= '[ux_html]'."\n";
                    $samples_markup .= '<div class="ws-card" style="border:1px solid #eee;border-radius:8px;padding:12px;background:#fafafa">';
                    $samples_markup .= '<a href="'.esc_url($url).'" target="_blank" rel="noopener">'.esc_html(basename($url)).'</a>';
                    if (!empty($desc)) {
                        $samples_markup .= '<div class="uploadtext" style="margin-top:6px">'.esc_html($desc).'</div>';
                    }
                    $samples_markup .= '</div>'."\n";
                    $samples_markup .= '[/ux_html]'."\n";
                }
                $samples_markup .= '[/col]'."\n";
            }
        }

        // ---- Build Services markup ----
        $products_markup = '';
        if ($products) {
            foreach ($products as $p) {
                $prod      = wc_get_product($p->ID);
                if (!$prod) continue;
                $thumb_id  = get_post_thumbnail_id($p->ID);
                $permalink = get_permalink($p->ID);
                $title     = get_the_title($p->ID);
                $price     = $prod->get_price_html();

                $products_markup .= '[col span="4" span__sm="12" class="svc-item"]'."\n";
                if ($thumb_id) {
                    $products_markup .= '[ux_image_box img="'.intval($thumb_id).'" image_height="70%" image_size="large" text_align="left" text_padding="2rem 1rem 1rem 1rem"]'."\n";
                } else {
                    $products_markup .= '[ux_image_box image_height="70%" text_align="left" text_padding="2rem 1rem 1rem 1rem"]'."\n";
                }
                $products_markup .= '<h4 class="uploadtitle"><a href="'.esc_url($permalink).'" style="text-decoration:none">'.esc_html($title).'</a></h4>'."\n";
                if (!empty($price)) {
                    // Price may include <span> etc; allow safe HTML
                    $products_markup .= '<p class="uploadtext">'.wp_kses_post($price).'</p>'."\n";
                }
                $products_markup .= '[/ux_image_box]'."\n";
                $products_markup .= '[/col]'."\n";
            }
        }

        // ---- Sections: Back + Bio ----
        $back_section = '[section label="Back Section" bg_color="rgb(249, 249, 250)" padding="0px"]
[row style="collapse"]
[col span__sm="12"]
<p class="backtoallbutton" style="margin-bottom:0;line-height:4;padding-left:15px;"><a href="'.esc_url($archive_url).'">BACK TO ALL</a></p>
[/col]
[/row]
[/section]';

        $bio_html = $bio ? wpautop($bio) : '';
        $bio_section = '[section label="Bio Section" padding__sm="3rem"]
[gap height="3rem" height__sm="1rem"]
[row class="rowmiddleprofile"]
[col span="4" span__sm="12" align="center"]
[ux_html]<img src="'.esc_url($avatar).'" alt="'.esc_attr($name).'" class="avatarimg" style="width:55%;height:auto;max-width:220px;border-radius:50%;object-fit:cover">[/ux_html]
<h2 class="profilename">'.esc_html($name).'</h2>
<p class="profilesecondary">'.esc_html($shop ?: '').'</p>
[/col]
[col span="8" span__sm="12" padding="0px 0px 0px 3rem" padding__sm="1rem 0px 0px 0px"]
<h1 class="profilemain" style="text-transform:uppercase;">'.esc_html($possessive).' BIO</h1>
[ux_html]<div class="profiletext">'.$bio_html.'</div>[/ux_html]
[/col]
[/row]
[/section]';

        // ---- Work Samples section ----
        $samples_section = '';
        if (!empty($samples_markup)) {
            $has_more = count($samples) > 3;
            $samples_section = '[section label="Work Samples"]
[row class="rowmiddleprofile"]
[col span__sm="12"]
<h4 class="profileheadings" style="text-transform:uppercase;">'.esc_html($first_name).$apos.'S WORK SAMPLES</h4>
[/col]
[/row]
[row id="work-samples-grid" class="rowmiddleprofile"]
'.$samples_markup.'
[/row]
[row class="rowmiddleprofile"]
[col span__sm="12" align="right"]
'.($has_more ? '' : '').'
[/col]
[/row]
[ux_html]
<style>
  #work-samples-grid .ws-item { display:none; }
  #work-samples-grid .ws-item.ws-visible { display:block; }
</style>
<script>
(function(){
  var container = document.getElementById("work-samples-grid");
  if(!container) return;
  var items = Array.prototype.slice.call(container.querySelectorAll(".ws-item"));
  var btn = document.getElementById("work-samples-load-more");
  var batch = 3, shown = 0;
  function showNext(n){
    for (var i = shown; i < Math.min(shown + n, items.length); i++){
      items[i].classList.add("ws-visible");
    }
    shown = Math.min(shown + n, items.length);
    if (shown >= items.length && btn) btn.style.display = "none";
  }
  showNext(batch);
  if (btn){
    btn.addEventListener("click", function(e){ e.preventDefault(); showNext(batch); });
  }
})();
</script>
[/ux_html]
[/section]';
        }

        // ---- Services section ----
        $services_section = '';
        if (!empty($products_markup)) {
            $has_more_services = count($products) > 3;
            $services_section = '[section label="Services Offered"]
[row class="rowmiddleprofile"]
[col span__sm="12"]
<h4 class="profileheadings" style="text-transform:uppercase;">SERVICES OFFERED BY '.esc_html($first_name).'</h4>
[/col]
[/row]
[row id="services-grid" class="rowmiddleprofile"]
'.$products_markup.'
[/row]
[row]
[col span__sm="12" align="right"]
'.($has_more_services ? '' : '').'
[/col]
[/row]
[ux_html]
<style>
  #services-grid .svc-item { display:none; }
  #services-grid .svc-item.svc-visible { display:block; }
</style>
<script>
(function(){
  var container = document.getElementById("services-grid");
  if(!container) return;
  var items = Array.prototype.slice.call(container.querySelectorAll(".svc-item"));
  var btn = document.getElementById("services-load-more");
  var batch = 3, shown = 0;
  function showNext(n){
    for (var i = shown; i < Math.min(shown + n, items.length); i++){
      items[i].classList.add("svc-visible");
    }
    shown = Math.min(shown + n, items.length);
    if (shown >= items.length && btn) btn.style.display = "none";
  }
  showNext(batch);
  if (btn){
    btn.addEventListener("click", function(e){ e.preventDefault(); showNext(batch); });
  }
})();
</script>
[/ux_html]
[/section]';
        }

        // ---- Compose final layout ----
        $layout  = $back_section . "\n" . $bio_section . "\n";
        if ($samples_section)  $layout .= $samples_section . "\n";
        if ($services_section) $layout .= $services_section . "\n";

        // Let Flatsome parse everything
        return do_shortcode($layout);
    }
}
