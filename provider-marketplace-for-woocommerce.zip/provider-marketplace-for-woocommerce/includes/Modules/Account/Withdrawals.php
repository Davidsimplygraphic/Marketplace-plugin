<?php
namespace SGPM\Modules\Account;

use SGPM\Constants;
use SGPM\Helpers;

if (!defined('ABSPATH')) exit;

/**
 * Unified Withdrawals endpoint
 * - Uses slsr_get_provider_balances() for figures (single source of truth)
 * - Creates sl_withdrawal CPT like slsr_handle_new_withdrawal()
 * - Lists previous withdrawals
 */
class Withdrawals {

  /** Nonce/action (kept compatible with your existing form naming) */
  const NONCE_KEY   = 'sl_sr2_new_withdrawal';
  const NONCE_ACTION= 'sl_sr2_new_withdrawal';

  /** Endpoint fallback if Constants::EP_WITHDRAWALS is missing */
  protected function endpoint_slug(): string {
    return defined(Constants::class.'::EP_WITHDRAWALS')
      ? Constants::EP_WITHDRAWALS
      : 'withdrawals';
  }

  public function init(): void {
    add_filter('woocommerce_account_menu_items', [$this,'menu_items'], 99, 1);
    add_action('woocommerce_account_' . $this->endpoint_slug() . '_endpoint', [$this,'render']);
    add_action('template_redirect', [$this,'handle_request']);
  }

  /**
   * Only show "Withdrawals" to providers. Also prevents duplicates.
   */
  public function menu_items($items){
    // Remove to avoid duplicates from other filters
    unset($items[ $this->endpoint_slug() ]);

    // Only add for logged-in providers
    if (!is_user_logged_in() || !Helpers::is_provider()) {
      return $items;
    }

    // Insert after 'orders' if present; else append
    $new       = [];
    $inserted  = false;
    foreach ($items as $key => $label) {
      $new[$key] = $label;
      if (!$inserted && $key === 'orders') {
        $new[ $this->endpoint_slug() ] = __('Withdrawals','provider-marketplace');
        $inserted = true;
      }
    }
    if (!$inserted) {
      $new[ $this->endpoint_slug() ] = __('Withdrawals','provider-marketplace');
    }
    return $new;
  }

  /**
   * Endpoint UI — uses slsr_get_provider_balances() and shows CPT list
   */
  public function render(){
    // Hard block direct URL access for non-providers
    if (!is_user_logged_in() || !Helpers::is_provider()) {
      wc_add_notice(__('You must be a provider to access Withdrawals.','provider-marketplace'), 'error');
      wp_safe_redirect(wc_get_page_permalink('myaccount'));
      exit;
    }

    $uid = get_current_user_id();

    // === BALANCES (single source of truth)
    $bals = function_exists('\\slsr_get_provider_balances')
      ? \slsr_get_provider_balances($uid)
      : ['pending'=>0,'available'=>0,'requested'=>0,'paid'=>0];

    echo '<h3>'.esc_html__('Withdrawals','provider-marketplace').'</h3>';
    echo '<p>'.sprintf(
      esc_html__('Pending: %1$s • Available: %2$s • Requested: %3$s • Paid: %4$s','provider-marketplace'),
      function_exists('wc_price') ? wc_price(max(0,(float)($bals['pending']   ?? 0))) : esc_html(number_format((float)($bals['pending']??0),2)),
      function_exists('wc_price') ? wc_price(max(0,(float)($bals['available'] ?? 0))) : esc_html(number_format((float)($bals['available']??0),2)),
      function_exists('wc_price') ? wc_price(max(0,(float)($bals['requested'] ?? 0))) : esc_html(number_format((float)($bals['requested']??0),2)),
      function_exists('wc_price') ? wc_price(max(0,(float)($bals['paid']      ?? 0))) : esc_html(number_format((float)($bals['paid']??0),2))
    ).'</p>';

    // Notices from redirect query args (optional compat)
    if (!empty($_GET['sl_sr2_done'])) {
      echo '<div class="woocommerce-message">'.esc_html__('Request submitted.','provider-marketplace').'</div>';
    }
    if (!empty($_GET['sl_sr2_error'])) {
      echo '<div class="woocommerce-error">'.esc_html(wp_unslash($_GET['sl_sr2_error'])).'</div>';
    }

    // === REQUEST FORM (disabled if nothing to withdraw)
    if (empty($bals['available']) || (float)$bals['available'] <= 0){
      echo '<p>'.esc_html__('Nothing to withdraw yet. Jobs must be paid and marked complete by your customers.','provider-marketplace').'</p>';
    } else {
      ?>
      <form method="post">
        <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_KEY); ?>
        <p><?php esc_html_e('Request payout of your AVAILABLE balance. Admin will review and pay to your saved payout method.','provider-marketplace'); ?></p>
        <button class="button button-primary" type="submit" name="sgpm_request_payout" value="1">
          <?php
            echo esc_html__('Request Withdrawal of ','provider-marketplace');
            echo function_exists('wc_price')
              ? wp_kses_post(wc_price((float)$bals['available']))
              : esc_html(number_format((float)$bals['available'],2));
          ?>
        </button>
      </form>
      <?php
    }

    // === PAST WITHDRAWALS (CPT: sl_withdrawal)
    $wd = new \WP_Query(array(
      'post_type'      => 'sl_withdrawal',
      'author'         => $uid,
      'posts_per_page' => 10,
      'orderby'        => 'date',
      'order'          => 'DESC',
      'no_found_rows'  => true,
      'fields'         => 'ids',
    ));
    if ($wd->have_posts()){
      echo '<table class="shop_table" style="margin-top:16px"><thead><tr><th>'.esc_html__('Date','provider-marketplace').'</th><th>'.esc_html__('Status','provider-marketplace').'</th><th>'.esc_html__('Amount','provider-marketplace').'</th></tr></thead><tbody>';
      foreach($wd->posts as $wid){
        $state = get_post_meta($wid,'_sl_w_state',true) ?: 'pending';
        $amt   = (float) get_post_meta($wid,'_sl_w_amount',true);
        $date  = get_post_field('post_date_gmt',$wid);
        echo '<tr>';
        echo '<td>'.esc_html(get_date_from_gmt($date,'M j, Y H:i')).'</td>';
        echo '<td>'.esc_html(ucfirst($state)).'</td>';
        echo '<td>'.(function_exists('wc_price') ? wp_kses_post(wc_price($amt)) : esc_html(number_format($amt,2))).'</td>';
        echo '</tr>';
      }
      echo '</tbody></table>';
    }
    wp_reset_postdata();
  }

  /**
   * Form handler — mirrors slsr_handle_new_withdrawal() logic
   */
  public function handle_request(){
    // Only process on the withdrawals endpoint, for providers, with a valid nonce + submit
    if (!is_user_logged_in() || !Helpers::is_account_endpoint($this->endpoint_slug())) return;
    if (!Helpers::is_provider()) return;

    // Only react to our specific POST
    if (empty($_POST['sgpm_request_payout'])) return;
    if (empty($_POST[self::NONCE_KEY]) || !wp_verify_nonce($_POST[self::NONCE_KEY], self::NONCE_ACTION)) {
      wc_add_notice(__('Security check failed.','provider-marketplace'), 'error');
      wp_safe_redirect(wc_get_account_endpoint_url($this->endpoint_slug()));
      exit;
    }

    $uid = get_current_user_id();

    // Re-check balance using same source as UI
    $b = function_exists('\\slsr_get_provider_balances') ? \slsr_get_provider_balances($uid) : ['available'=>0];
    if (empty($b['available']) || (float)$b['available'] <= 0) {
      wc_add_notice(__('No available balance to withdraw.','provider-marketplace'), 'error');
      wp_safe_redirect(wc_get_account_endpoint_url($this->endpoint_slug()));
      exit;
    }

    // Build eligible items (mirrors your slsr_handle_new_withdrawal)
    $eligible = [];
    $reqs = new \WP_Query(array(
      'post_type'      => 'service_request',
      'post_status'    => array('publish','pending','draft'),
      'posts_per_page' => -1,
      'meta_query'     => array(array(
        'key'     => '_sl_assigned_provider',
        'value'   => $uid,
        'compare' => '=',
        'type'    => 'NUMERIC'
      )),
      'fields'         => 'ids',
      'no_found_rows'  => true,
    ));

    if($reqs->have_posts()){
      foreach($reqs->posts as $rid){
        $status    = get_post_meta($rid,'_sl_status',true);
        $qid       = (int) get_post_meta($rid,'_sl_assigned_quote',true);
        $order_id  = (int) get_post_meta($rid,'_sl_order_id',true);
        $withdrawn = (int) get_post_meta($rid,'_sl_withdrawal_id',true);

        if($withdrawn) continue;
        if($status !== 'completed') continue;
        if(!$order_id) continue;

        $order = function_exists('wc_get_order') ? wc_get_order($order_id) : null;
        if(!$order || !$order->has_status(array('processing','completed'))) continue;

        $price = ($qid ? (float) get_post_meta($qid,'_slq_price',true) : 0.0);
        $dec   = function_exists('wc_get_price_decimals') ? wc_get_price_decimals() : 2;
        $rate  = defined('SLSR_COMMISSION_RATE') ? SLSR_COMMISSION_RATE : 0.10; // fallback 10% if not defined
        $net   = max(0, $price - round($price * $rate, $dec));

        if($net > 0) {
          $eligible[$rid] = $net;
        }
      }
    }
    wp_reset_postdata();

    if(!$eligible){
      wc_add_notice(__('No eligible items found.','provider-marketplace'), 'error');
      wp_safe_redirect(wc_get_account_endpoint_url($this->endpoint_slug()));
      exit;
    }

    // Create withdrawal CPT
    $provider_label = function_exists('\\slsr_user_display')
      ? \slsr_user_display($uid)
      : (get_userdata($uid) ? get_userdata($uid)->display_name : ('User #'.$uid));

    $wid = wp_insert_post(array(
      'post_type'    => 'sl_withdrawal',
      'post_status'  => 'publish',
      'post_title'   => 'Withdrawal request by '.$provider_label.' ('.date_i18n('Y-m-d H:i').')',
      'post_content' => 'Auto-created from available balances.',
      'post_author'  => $uid,
    ));

    if(is_wp_error($wid)){
      wc_add_notice(sprintf(__('Could not create withdrawal: %s','provider-marketplace'), $wid->get_error_message()), 'error');
      wp_safe_redirect(wc_get_account_endpoint_url($this->endpoint_slug()));
      exit;
    }

    $amount = array_sum($eligible);
    update_post_meta($wid,'_sl_w_state','pending');
    update_post_meta($wid,'_sl_w_amount',$amount);
    update_post_meta($wid,'_sl_w_items', array_keys($eligible));

    foreach(array_keys($eligible) as $rid){
      update_post_meta($rid,'_sl_withdrawal_id', $wid);
    }

    // Notify admin (compat with your original)
    $admin = get_bloginfo('admin_email');
    if($admin){
      $price_str = function_exists('wc_price') ? wp_strip_all_tags(wc_price($amount)) : number_format((float)$amount,2);
      wp_mail(
        $admin,
        'New withdrawal request',
        "Provider: {$provider_label} (ID: {$uid})\n".
        "Amount: {$price_str}\n".
        "Requests: ".implode(', ', array_keys($eligible))."\n\n".
        "Review in WP Admin → Withdrawals."
      );
    }

    wc_add_notice(__('Payout requested. We’ll notify you once paid.','provider-marketplace'));
    wp_safe_redirect(wc_get_account_endpoint_url($this->endpoint_slug()));
    exit;
  }
}
