<?php
namespace SGPM\Modules\Account;

use SGPM\Constants;
use SGPM\Helpers;
use SGPM\Modules\Profiles;

if (!defined('ABSPATH')) exit;

class ProviderDetails {
    public function init(): void {
        add_filter('woocommerce_account_menu_items', [$this,'menu_items']);
        add_action('woocommerce_account_' . Constants::EP_PROVIDER_DETAILS . '_endpoint', [$this,'render']);
        add_action('template_redirect', [$this,'handle_submit']);
    }

    public function menu_items($items){
        if (!is_user_logged_in()) return $items;
        $u = wp_get_current_user();
        if (!in_array(Constants::ROLE, (array)$u->roles, true)) return $items;

        $out = [];
        foreach ($items as $key => $label) {
            $out[$key] = $label;
            if ($key === 'dashboard') {
                $out[Constants::EP_PROVIDER_DETAILS] = __('Provider Details','provider-marketplace');
            }
        }
        if (!isset($out[Constants::EP_PROVIDER_DETAILS])) {
            $out[Constants::EP_PROVIDER_DETAILS] = __('Provider Details','provider-marketplace');
        }
        return $out;
    }

    public function render(){
        if (!Helpers::is_provider()) { echo esc_html__('You must be a Provider to access this page.','provider-marketplace'); return; }
        $uid = get_current_user_id();
        $user = get_userdata($uid);

        // Ensure profile exists
        $profile_id = (int) get_user_meta($uid, Constants::META_PROFILE_POST, true);
        if (!$profile_id) $profile_id = Profiles::create_profile_for_user($uid);
        $profile_url = $profile_id ? get_permalink($profile_id) : '';

        // Allow for an optional Constants::META_PHONE; fallback to 'phone'
        $meta_phone_key = \defined('SGPM\Constants::META_PHONE') ? Constants::META_PHONE : 'phone';

        // Current values
        $shop   = get_user_meta($uid, Constants::META_SHOP_NAME, true);
        $bio    = get_user_meta($uid, Constants::META_BIO, true);
        $ptype  = get_user_meta($uid, Constants::META_PAYOUT_TYPE, true) ?: 'bank';
        $pemail = get_user_meta($uid, Constants::META_PAYOUT_EMAIL, true);
        $bname  = get_user_meta($uid, Constants::META_BANK_NAME, true);
        $bacc   = get_user_meta($uid, Constants::META_BANK_ACC, true);
        $bbranch= get_user_meta($uid, Constants::META_BANK_BRANCH, true);
        $phone  = get_user_meta($uid, $meta_phone_key, true);

        $avatar_id  = (int) get_user_meta($uid, Constants::META_AVATAR_ID, true);
        $avatar_url = $avatar_id ? wp_get_attachment_image_url($avatar_id, 'thumbnail') : '';

        echo '<h4 class="headeraccound">'.esc_html__('Provider Details','provider-marketplace').'</h4>';
        if ($profile_url) {
            echo '<p><a class="button" target="_blank" href="'.esc_url($profile_url).'">'.esc_html__('View my public page','provider-marketplace').'</a></p>';
        } ?>

        <form method="post" class="woocommerce-EditAccountForm edit-account" enctype="multipart/form-data" style="max-width:760px">
            <?php wp_nonce_field(Constants::NONCE_PD, Constants::NONCE_PD); ?>
            <fieldset>
                <h4 class="headeraccound"><?php esc_html_e('Provider Profile','provider-marketplace'); ?></h4>
                <p class="form-row form-row-first">
                    <label for="sgpm_avatar"><?php esc_html_e('Avatar (image)','provider-marketplace'); ?></label>
                    <input type="file" name="sgpm_avatar" id="sgpm_avatar" accept="image/*">
                    <?php if ($avatar_url): ?>
                        <br><img src="<?php echo esc_url($avatar_url); ?>" alt="" style="margin-top:.5rem;width:128px;height:128px;border-radius:50%;object-fit:cover;">
                    <?php endif; ?>
                </p>
                <p class="form-row form-row-last">
                    <label for="sgpm_shop_name"><?php esc_html_e('Shop / Provider Name','provider-marketplace'); ?> *</label>
                    <input type="text" name="sgpm_shop_name" id="sgpm_shop_name" value="<?php echo esc_attr($shop); ?>" required>
                </p>

                <div class="clear"></div>

                <p class="form-row form-row-wide">
                    <label for="sgpm_bio"><?php esc_html_e('Short Bio','provider-marketplace'); ?></label>
                    <textarea name="sgpm_bio" id="sgpm_bio" rows="4"><?php echo esc_textarea($bio); ?></textarea>
                </p>
            </fieldset>

            <fieldset>
                <!-- <legend><?php esc_html_e('Account Identity','provider-marketplace'); ?></legend> -->

                <p class="form-row form-row-first">
                    <label for="sgpm_first_name"><?php esc_html_e('First name','provider-marketplace'); ?> *</label>
                    <input type="text" name="sgpm_first_name" id="sgpm_first_name" value="<?php echo esc_attr($user->first_name); ?>" required>
                </p>
                <p class="form-row form-row-last">
                    <label for="sgpm_last_name"><?php esc_html_e('Last name','provider-marketplace'); ?> *</label>
                    <input type="text" name="sgpm_last_name" id="sgpm_last_name" value="<?php echo esc_attr($user->last_name); ?>" required>
                </p>
                <div class="clear"></div>

                <p class="form-row form-row-first">
                    <label for="sgpm_email"><?php esc_html_e('Email address','provider-marketplace'); ?> *</label>
                    <input type="email" name="sgpm_email" id="sgpm_email" value="<?php echo esc_attr($user->user_email); ?>" required>
                </p>
                <p class="form-row form-row-last">
                    <label for="sgpm_phone"><?php esc_html_e('Phone','provider-marketplace'); ?></label>
                    <input type="text" name="sgpm_phone" id="sgpm_phone" value="<?php echo esc_attr($phone); ?>">
                </p>
                <div class="clear"></div>
            </fieldset>



            <fieldset>
                <h4 class="headeraccound"><?php esc_html_e('Payout Details','provider-marketplace'); ?></h4>

                <p class="form-row form-row-first">
                    <label for="sgpm_payout_type"><?php esc_html_e('Payout Method','provider-marketplace'); ?></label>
                    <select name="sgpm_payout_type" id="sgpm_payout_type">
                        <option value="bank"   <?php selected($ptype,'bank');   ?>><?php esc_html_e('Bank Transfer','provider-marketplace'); ?></option>
                        <option value="paypal" <?php selected($ptype,'paypal'); ?>><?php esc_html_e('PayPal','provider-marketplace'); ?></option>
                    </select>
                </p>
                <p class="form-row form-row-last">
                    <label for="sgpm_payout_email"><?php esc_html_e('PayPal Email (if using PayPal)','provider-marketplace'); ?></label>
                    <input type="email" name="sgpm_payout_email" id="sgpm_payout_email" value="<?php echo esc_attr($pemail); ?>">
                </p>
                <div class="clear"></div>

                <p class="form-row form-row-first">
                    <label for="sgpm_bank_name"><?php esc_html_e('Bank Name','provider-marketplace'); ?></label>
                    <input type="text" name="sgpm_bank_name" id="sgpm_bank_name" value="<?php echo esc_attr($bname); ?>">
                </p>
                <p class="form-row form-row-last">
                    <label for="sgpm_bank_acc"><?php esc_html_e('Account Number / IBAN','provider-marketplace'); ?></label>
                    <input type="text" name="sgpm_bank_acc" id="sgpm_bank_acc" value="<?php echo esc_attr($bacc); ?>">
                </p>
                <p class="form-row form-row-wide">
                    <label for="sgpm_bank_branch"><?php esc_html_e('Branch / SWIFT / Routing','provider-marketplace'); ?></label>
                    <input type="text" name="sgpm_bank_branch" id="sgpm_bank_branch" value="<?php echo esc_attr($bbranch); ?>">
                </p>
            </fieldset>

            <p><button type="submit" class="button button-primary buttonsaveprofile"><?php esc_html_e('Save Provider Details','provider-marketplace'); ?></button></p>
        </form>
        <?php
    }

    public function handle_submit(){
        if (!is_user_logged_in() || !Helpers::is_account_endpoint(Constants::EP_PROVIDER_DETAILS)) return;
        if (!isset($_POST[Constants::NONCE_PD]) || !wp_verify_nonce($_POST[Constants::NONCE_PD], Constants::NONCE_PD)) return;
        if (!Helpers::is_provider()) return;

        $uid  = get_current_user_id();
        $user = get_userdata($uid);

        // Optional class constant for phone, else 'phone'
        $meta_phone_key = \defined('SGPM\Constants::META_PHONE') ? Constants::META_PHONE : 'phone';

        // Gather + sanitize
        $first  = sanitize_text_field($_POST['sgpm_first_name'] ?? '');
        $last   = sanitize_text_field($_POST['sgpm_last_name'] ?? '');
        $email  = sanitize_email($_POST['sgpm_email'] ?? '');
        $phone  = sanitize_text_field($_POST['sgpm_phone'] ?? '');

        $shop   = sanitize_text_field($_POST['sgpm_shop_name'] ?? '');
        $bio    = wp_kses_post($_POST['sgpm_bio'] ?? '');

        $ptype  = in_array(($_POST['sgpm_payout_type'] ?? 'bank'), ['bank','paypal'], true) ? $_POST['sgpm_payout_type'] : 'bank';
        $pemail = sanitize_email($_POST['sgpm_payout_email'] ?? '');

        $bname  = sanitize_text_field($_POST['sgpm_bank_name'] ?? '');
        $bacc   = sanitize_text_field($_POST['sgpm_bank_acc'] ?? '');
        $bbranch= sanitize_text_field($_POST['sgpm_bank_branch'] ?? '');

        // Validate
        $errors = [];

        if ($first === '') $errors[] = __('First name is required.','provider-marketplace');
        if ($last === '')  $errors[] = __('Last name is required.','provider-marketplace');
        if ($shop === '')  $errors[] = __('Shop / Provider Name is required.','provider-marketplace');

        if ($email === '' || !is_email($email)) {
            $errors[] = __('A valid email address is required.','provider-marketplace');
        } elseif ($email !== $user->user_email && email_exists($email)) {
            $errors[] = __('That email is already in use by another account.','provider-marketplace');
        }

        if ($ptype === 'paypal' && ($pemail === '' || !is_email($pemail))) {
            $errors[] = __('Please enter a valid PayPal email for PayPal payouts.','provider-marketplace');
        }

        // Avatar upload (optional)
        $new_avatar_id = 0;
        if (!empty($_FILES['sgpm_avatar']['name'])) {
            $id = Helpers::handle_image_upload($_FILES['sgpm_avatar'], $uid);
            if ($id) {
                $new_avatar_id = (int) $id;
            } else {
                $errors[] = __('Avatar upload failed. Please try a different image.','provider-marketplace');
            }
        }

        if (!empty($errors)) {
            foreach ($errors as $e) wc_add_notice($e, 'error');
            return; // show notices without redirect
        }

        // Update core user fields
        $update = [
            'ID'           => $uid,
            'first_name'   => $first,
            'last_name'    => $last,
            'display_name' => $shop !== '' ? $shop : ($first . ' ' . $last),
            'description'  => $bio, // keep WP "biographical info" in sync
        ];
        if ($email !== $user->user_email) {
            $update['user_email'] = $email;
        }
        $res = wp_update_user($update);
        if (is_wp_error($res)) {
            wc_add_notice($res->get_error_message(), 'error');
            return;
        }

        // Update meta
        update_user_meta($uid, Constants::META_SHOP_NAME,   $shop);
        update_user_meta($uid, Constants::META_BIO,         $bio);
        update_user_meta($uid, $meta_phone_key,             $phone);

        update_user_meta($uid, Constants::META_PAYOUT_TYPE,  $ptype);
        update_user_meta($uid, Constants::META_PAYOUT_EMAIL, $pemail);
        update_user_meta($uid, Constants::META_BANK_NAME,    $bname);
        update_user_meta($uid, Constants::META_BANK_ACC,     $bacc);
        update_user_meta($uid, Constants::META_BANK_BRANCH,  $bbranch);

        if ($new_avatar_id) {
            update_user_meta($uid, Constants::META_AVATAR_ID, $new_avatar_id);
        }

        // Ensure provider profile post exists/updates
        Profiles::create_profile_for_user($uid);

        wc_add_notice(__('Provider details saved.','provider-marketplace'));
        wp_safe_redirect(wc_get_account_endpoint_url(Constants::EP_PROVIDER_DETAILS));
        exit;
    }
}
