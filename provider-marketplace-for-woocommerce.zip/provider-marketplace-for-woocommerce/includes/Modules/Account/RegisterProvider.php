<?php
namespace SGPM\Modules\Account;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

/**
 * [sl_register_provider]
 *
 * Visibility:
 * - Logged OUT -> show full registration form (first/last, email, password, phone)
 * - Logged IN & already PROVIDER -> show CTA (via do_shortcode_tag filter) with "You're already logged in as a Service Provider" + View Dashboard
 * - Logged IN & NOT PROVIDER (e.g., Customer) -> show notice with logout instruction + logout link (no form)
 *
 * Submission:
 * - Logged OUT submit -> create user (Woo if available), add provider role, log in, redirect to Provider Details.
 * - Logged IN submit -> if Provider, redirect to Provider Details; if NOT Provider, force logout redirect so they can register.
 *
 * Provider Details URL is built dynamically from the site's domain (Woo My Account endpoint if available).
 */
class RegisterProvider {

  /** store validation errors and previous values for the same request */
  protected static $errors = [];
  protected static $old = [];

  public function init(): void {
    add_shortcode('sl_register_provider', [$this, 'shortcode']);
    add_action('template_redirect', [$this, 'handle_submit']);

    // Integrated: Logged-in replacement UI for [sl_register_provider] when user already has Provider role
    add_filter('do_shortcode_tag', [$this, 'maybe_replace_shortcode_output'], 10, 4);
    add_action('wp_enqueue_scripts', [$this, 'enqueue_inline_styles']);
  }

  /* --------------------------- Submit handler ---------------------------- */
  public function handle_submit(): void {
    if (empty($_POST['sgpm_provider_register_submit'])) {
      return;
    }

    // Nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'sgpm_provider_register')) {
      self::$errors[] = __('Security check failed. Please try again.', 'provider-marketplace');
      return;
    }

    // If logged in, no form should be submitted; route accordingly.
    if (is_user_logged_in()) {
      $user = wp_get_current_user();
      if ($this->user_has_provider_role($user)) {
        wp_safe_redirect($this->get_provider_details_url());
        exit;
      }
      // Not a provider (e.g., Customer): ask them to log out first — send through a logout URL.
      $logout_redirect = $this->current_url();
      wp_safe_redirect(wp_logout_url($logout_redirect));
      exit;
    }

    // Gather & sanitize (logged-out registration)
    $first = sanitize_text_field(wp_unslash($_POST['first_name'] ?? ''));
    $last  = sanitize_text_field(wp_unslash($_POST['last_name'] ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $pass  = (string)($_POST['password'] ?? '');
    $pass2 = (string)($_POST['password_confirm'] ?? '');
    $phone = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));

    self::$old = compact('first', 'last', 'email', 'phone');

    // Validate
    if ($first === '') self::$errors[] = __('First name is required.', 'provider-marketplace');
    if ($last === '')  self::$errors[] = __('Last name is required.', 'provider-marketplace');

    if ($email === '' || !is_email($email)) {
      self::$errors[] = __('Please enter a valid email address.', 'provider-marketplace');
    } elseif ($email && email_exists($email)) {
      self::$errors[] = __('An account with that email already exists. Please log in instead.', 'provider-marketplace');
    }

    if (strlen($pass) < 8) self::$errors[] = __('Password must be at least 8 characters.', 'provider-marketplace');
    if ($pass !== $pass2)  self::$errors[] = __('Passwords do not match.', 'provider-marketplace');

    if (!empty(self::$errors)) {
      // Let the shortcode render the form with errors in the same request.
      return;
    }

    // Create the user (prefer Woo helper)
    $user_id = 0;

    // Build a username from email's left part; ensure uniqueness
    $username_base = sanitize_user((string)strstr($email, '@', true));
    if ($username_base === '') {
      $username_base = sanitize_user(current(explode('@', $email))); // fallback
    }
    $username = $username_base;
    if (username_exists($username)) {
      $username .= wp_rand(1000, 9999);
    }

    if (function_exists('wc_create_new_customer')) {
      $user_id = wc_create_new_customer($email, $username, $pass);
      if (is_wp_error($user_id)) {
        self::$errors[] = $user_id->get_error_message();
        return;
      }
    } else {
      $user_id = wp_create_user($username, $pass, $email);
      if (is_wp_error($user_id)) {
        self::$errors[] = $user_id->get_error_message();
        return;
      }
      // Make sure new user is at least a customer
      $u = new \WP_User($user_id);
      if (!in_array('customer', (array)$u->roles, true)) {
        $u->add_role('customer');
      }
    }

    // Set profile fields
    update_user_meta($user_id, 'first_name', $first);
    update_user_meta($user_id, 'last_name',  $last);
    if ($phone) {
      update_user_meta($user_id, 'billing_phone', $phone);
    }

    // Add provider role alongside customer
    $u = new \WP_User($user_id);
    if ($this->provider_role_constant_exists()) {
      $u->add_role(Constants::ROLE);
    } else {
      $u->add_role('provider'); // fallback slug if constant missing
    }

    // Log them in
    if (function_exists('wc_set_customer_auth_cookie')) {
      // Sets the auth cookie and starts a Woo session
      wc_set_customer_auth_cookie($user_id);
    } else {
      wp_set_current_user($user_id);
      wp_set_auth_cookie($user_id, true);
    }

    // Go straight to the Provider Details URL (dynamic)
    wp_safe_redirect($this->get_provider_details_url());
    exit;
  }

  /* --------------------------- Shortcode renderer ---------------------------- */
  public function shortcode($atts = [], $content = ''): string {
    $is_logged_in = is_user_logged_in();
    $current_user = $is_logged_in ? wp_get_current_user() : null;
    $has_provider = $is_logged_in ? $this->user_has_provider_role($current_user) : false;

    // If logged in AND already a provider -> (normally) show CTA to Provider Details
    // Note: when provider, our do_shortcode_tag filter may replace the output entirely with the dashboard block.
    if ($is_logged_in && $has_provider) {
      $target = $this->get_provider_details_url();
      $name = $current_user && $current_user->exists() ? ($current_user->display_name ?: $current_user->user_login) : '';

      ob_start(); ?>
      <div class="sl-register-provider-logged-in" style="max-width:780px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:16px;background:#fe6601;color:#fff;padding:14px 22px;border-radius:999px;">
        <div style="font-weight:600;">
          <?php echo esc_html(sprintf(__('You’re logged in%s', 'provider-marketplace'), $name ? ', '.$name : '.')); ?>
        </div>
        <a class="buttonnew" href="<?php echo esc_url($target); ?>">
          <?php echo esc_html__('Continue to Provider Details', 'provider-marketplace'); ?>
        </a>
      </div>
      <?php
      return ob_get_clean();
    }

    // If logged in but NOT provider (e.g., Customer): show login bar + logout instruction, no form
    if ($is_logged_in && !$has_provider) {
      $name = $current_user && $current_user->exists() ? ($current_user->display_name ?: $current_user->user_login) : '';
      $logout_url = wp_logout_url($this->current_url());

      ob_start(); ?>
      <div class="sl-register-provider-logged-in" style="max-width:780px;margin:0 auto;background:#fe6601;color:#fff;padding:14px 22px;border-radius:16px;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;">
          <div style="font-weight:600;">
            <?php echo esc_html(sprintf(__('You’re logged in%s', 'provider-marketplace'), $name ? ', '.$name : '.')); ?><br>
            <?php
            echo wp_kses_post(
              sprintf(
                /* translators: %s: logout link */
                __('To register as a Service Provider, please %s first.', 'provider-marketplace'),
                '<a href="'.esc_url($logout_url).'" style="color:#fff;text-decoration:underline;">'.esc_html__('log out', 'provider-marketplace').'</a>'
              )
            );
          ?>
          </div>
        </div>
      </div>
      <?php
      return ob_get_clean();
    }

    // Logged OUT: show registration form
    $old = (object) [
      'first' => self::$old['first'] ?? '',
      'last'  => self::$old['last']  ?? '',
      'email' => self::$old['email'] ?? '',
      'phone' => self::$old['phone'] ?? '',
    ];

    ob_start(); ?>
    <form class="sgpm-provider-register woocommerce-form woocommerce-form-register register" method="post" enctype="multipart/form-data" style="max-width:780px;margin:0 auto;">
      <h3><?php echo esc_html__('Register as a Service Provider', 'provider-marketplace'); ?></h3>

      <?php if (!empty(self::$errors)): ?>
        <div class="woocommerce-notices-wrapper">
          <ul class="woocommerce-error" role="alert">
            <?php foreach (self::$errors as $err): ?>
              <li><?php echo esc_html($err); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <p class="form-row form-row-first">
        <label for="first_name"><?php echo esc_html__('First name', 'provider-marketplace'); ?> *</label>
        <input type="text" name="first_name" id="first_name" value="<?php echo esc_attr($old->first); ?>" required />
      </p>

      <p class="form-row form-row-last">
        <label for="last_name"><?php echo esc_html__('Last name', 'provider-marketplace'); ?> *</label>
        <input type="text" name="last_name" id="last_name" value="<?php echo esc_attr($old->last); ?>" required />
      </p>

      <div class="clear"></div>

      <p class="form-row form-row-wide">
        <label for="email"><?php echo esc_html__('Email address', 'provider-marketplace'); ?> *</label>
        <input type="email" name="email" id="email" value="<?php echo esc_attr($old->email); ?>" required />
      </p>

      <p class="form-row form-row-first">
        <label for="password"><?php echo esc_html__('Password', 'provider-marketplace'); ?> *</label>
        <input type="password" name="password" id="password" required />
      </p>

      <p class="form-row form-row-last">
        <label for="password_confirm"><?php echo esc_html__('Confirm password', 'provider-marketplace'); ?> *</label>
        <input type="password" name="password_confirm" id="password_confirm" required />
      </p>

      <div class="clear"></div>

      <p class="form-row form-row-wide">
        <label for="phone"><?php echo esc_html__('Phone (optional)', 'provider-marketplace'); ?></label>
        <input type="text" name="phone" id="phone" value="<?php echo esc_attr($old->phone); ?>" />
      </p>

      <?php wp_nonce_field('sgpm_provider_register'); ?>
      <input type="hidden" name="sgpm_provider_register_submit" value="1" />

      <p class="form-row">
        <button type="submit" class="button button-primary">
          <?php echo esc_html__('Create Account', 'provider-marketplace'); ?>
        </button>
      </p>

      <p class="form-row">
        <?php $login_url = wp_login_url($this->get_provider_details_url()); ?>
        <small><?php echo esc_html__('Already have a Service Provider account?', 'provider-marketplace'); ?>
            <?php $login_url = home_url('/my-account/'); ?>
                <a class="loginlink" href="<?php echo esc_url($login_url); ?>"><?php echo esc_html__('Log in instead', 'provider-marketplace'); ?></a>
        </small>
      </p>
    </form>
    <?php
    return ob_get_clean();
  }

  /* --------------------------- do_shortcode_tag replacement (integrated snippet) ---------------------------- */

  /**
   * If the tag is `sl_register_provider` and the current user already has the Provider role,
   * replace the shortcode output with the "You're already logged in as a Service Provider" + "View Dashboard" UI.
   *
   * Mirrors your provided snippet, scoped so it triggers only for providers.
   *
   * @param string $output
   * @param string $tag
   * @param array  $attr
   * @param array  $m
   * @return string
   */
  public function maybe_replace_shortcode_output($output, $tag, $attr, $m) {
    if ($tag !== 'sl_register_provider' || is_admin()) {
      return $output;
    }
    if (!is_user_logged_in()) {
      return $output;
    }
    $user = wp_get_current_user();
    if (!$this->user_has_provider_role($user)) {
      return $output; // Only replace for actual Providers
    }

    $dashboard_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('myaccount') : home_url('/my-account/');
    /** Allow external override of the dashboard link (as in your snippet) */
    $dashboard_url = apply_filters('sl_register_provider_dashboard_url', $dashboard_url);

    return '<div class="sl-register-provider-logged-in"><span class="sl-notice-text">'.
      esc_html__("You're already logged in as a Service Provider",'sl-core').
      '</span><a class="buttonnew" href="'.esc_url($dashboard_url).'">'.
      esc_html__('View Dashboard','sl-core').
      '</a></div>';
  }

  /**
   * Enqueue inline styles for the replacement UI (exactly as in your snippet).
   */
  public function enqueue_inline_styles(): void {
    wp_register_style('sl-register-provider-inline', false);
    wp_enqueue_style('sl-register-provider-inline');
    wp_add_inline_style(
      'sl-register-provider-inline',
      '.sl-register-provider-logged-in{display:flex;align-items:center;gap:12px;padding:12px 16px;border-radius:6px}' .
      '.sl-register-provider-logged-in .buttonnew{margin-left:auto}'
    );
  }

  /* --------------------------- Helpers ---------------------------- */

  /**
   * Build the Provider Details URL from the site's domain dynamically.
   * - If WooCommerce is available, use the "provider-details" endpoint on the My Account page.
   * - Otherwise, fallback to a sensible path under the home URL.
   */
  protected function get_provider_details_url(): string {
    if (function_exists('wc_get_endpoint_url') && function_exists('wc_get_page_permalink')) {
      $base = wc_get_page_permalink('myaccount');
      $url  = wc_get_endpoint_url('provider-details', '', $base);
      return trailingslashit($url);
    }
    // Fallback without Woo
    return trailingslashit(home_url('/my-account/provider-details/'));
  }

  protected function provider_role_constant_exists(): bool {
    // `defined('Namespace\\Class::CONST')` works for class constants.
    return defined('SGPM\\Constants::ROLE');
  }

  protected function user_has_provider_role(\WP_User $user = null): bool {
    if (!$user || !$user->exists()) return false;
    $roles = (array) $user->roles;
    $provider_slug = $this->provider_role_constant_exists() ? Constants::ROLE : 'provider';
    return in_array($provider_slug, $roles, true);
  }

  /**
   * Current URL helper for redirecting after logout
   */
  protected function current_url(): string {
    $scheme = is_ssl() ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? '';
    $uri    = $_SERVER['REQUEST_URI'] ?? '';
    return esc_url_raw($scheme . '://' . $host . $uri);
  }
}
