<?php
namespace SGPM\Modules\Account;

use SGPM\Constants;
use SGPM\Helpers;

if (!defined('ABSPATH')) exit;

class YourServices {
    public function init(): void {
        add_filter('woocommerce_account_menu_items', [$this,'menu_items']);
        add_action('woocommerce_account_' . Constants::EP_YOUR_SERVICES . '_endpoint', [$this,'render']);
        add_action('template_redirect', [$this,'handle_service_submit']);
        add_action('template_redirect', [$this,'handle_service_delete']);
        add_action('template_redirect', [$this,'handle_samples_submit']);
        add_action('template_redirect', [$this,'handle_sample_delete']);
        add_action('template_redirect', [$this,'handle_sample_edit']);

        // Ensure .wav uploads are allowed (in case site blocks it)
        add_filter('upload_mimes', function($mimes){
            $mimes['wav']   = 'audio/wav';
            $mimes['wave']  = 'audio/wav';
            $mimes['x-wav'] = 'audio/x-wav';
            return $mimes;
        });
    }

    public function menu_items($items){
        if (!is_user_logged_in()) return $items;
        $u = wp_get_current_user();
        if (!in_array(Constants::ROLE, (array)$u->roles, true)) return $items;

        $out = [];
        foreach ($items as $key => $label) {
            $out[$key] = $label;
            if ($key === 'dashboard') {
                $out[Constants::EP_YOUR_SERVICES] = __('Your Services','provider-marketplace');
            }
        }
        if (!isset($out[Constants::EP_YOUR_SERVICES])) {
            $out[Constants::EP_YOUR_SERVICES] = __('Your Services','provider-marketplace');
        }
        return $out;
    }

    public function render(){
        if (!Helpers::is_provider()) { echo esc_html__('You must be a Provider to access this page.','provider-marketplace'); return; }
        $uid = get_current_user_id();

        // CHANGED: Make sure the editor assets load when we render rich text editors on the front-end
        if (function_exists('wp_enqueue_editor')) { \wp_enqueue_editor(); }

        $tab = isset($_GET['t']) ? sanitize_key($_GET['t']) : 'add';
        if (!in_array($tab, ['add','manage','samples'], true)) $tab = 'add';
        $base = esc_url(wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES));
        $link = fn($t) => add_query_arg('t', $t, $base);

        echo '<h3 class="headeraccound">'.esc_html__('Your Services','provider-marketplace').'</h3>';
        echo '<nav class="sgpm-tabs" style="margin-bottom:1rem;border-bottom:1px solid #e5e5e5;text-transform:uppercase">';
        $tabs = [
            'add'     => __('Add Service','provider-marketplace'),
            'manage'  => __('Manage Services','provider-marketplace'),
            'samples' => __('Upload Samples','provider-marketplace')
        ];
        foreach ($tabs as $k=>$label){
            $active = ($tab===$k) ? ' style="border-bottom:0px solid; padding:.5rem 1rem; display:inline-block; font-weight:600;color:#FE6601"' : ' style="padding:.5rem 1rem; display:inline-block;"';
            echo '<a href="'.esc_url($link($k)).'"'.$active.'>'.esc_html($label).'</a>';
        }
        echo '</nav>';

        if ($tab === 'add') {
            $this->render_service_add_edit($uid);
        } elseif ($tab === 'manage') {
            $this->render_services_table($uid);
        } else {
            $this->render_samples_uploader($uid);
            $this->render_samples_list($uid);
        }

        $summary = Helpers::get_provider_earnings_summary($uid);
        echo '<h4 style="margin-top:2rem">'.esc_html__('Earnings Summary','provider-marketplace').'</h4>';
        echo '<p>'.sprintf(
            wp_kses(__('From %1$d completed/processing order items, your total earnings are <strong>%2$s</strong> (at 80%%).','provider-marketplace'), ['strong'=>[]]),
            intval($summary['count']),
            wc_price($summary['total'])
        ).'</p>';
    }

    /* ---------- Add/Edit Service ---------- */

    private function render_service_add_edit(int $uid){
        $editing_id = isset($_GET['service_id']) ? absint($_GET['service_id']) : 0;
        $editing_post = ($editing_id && get_post_field('post_author', $editing_id) == $uid && get_post_type($editing_id)==='product') ? wc_get_product($editing_id) : null;

        $title = $editing_post ? $editing_post->get_name() : '';
        $price = $editing_post ? $editing_post->get_price() : '';
        $short = $editing_post ? $editing_post->get_short_description() : '';
        $desc  = $editing_post ? $editing_post->get_description() : '';

        // Preselected product_cat terms if editing
        $selected_cat_ids = [];
        if ($editing_post) {
            $selected_cat_ids = wp_get_post_terms($editing_id, 'product_cat', ['fields' => 'ids']);
            if (!is_array($selected_cat_ids)) $selected_cat_ids = [];
        }

        // All categories
        $all_terms = get_terms([
            'taxonomy'   => 'product_cat',
            'hide_empty' => false,
        ]);
        $term_map_for_js = [];
        $options_html = '';
        if (!is_wp_error($all_terms) && $all_terms) {
            foreach ($all_terms as $t) {
                $depth = count(get_ancestors($t->term_id, 'product_cat', 'taxonomy'));
                $label = str_repeat('— ', $depth) . $t->name;
                $options_html .= '<option value="'.esc_attr($t->term_id).'">'.esc_html($label).'</option>';
                $term_map_for_js[$t->term_id] = $t->name;
            }
        }

        echo '<div>'; ?>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field(Constants::NONCE_SVC, Constants::NONCE_SVC); ?>
            <?php if ($editing_post): ?>
                <input type="hidden" name="sgpm_service_id" value="<?php echo esc_attr($editing_id); ?>">
            <?php endif; ?>
            <p class="form-row form-row-first">
                <label for="sgpm_title"><?php esc_html_e('Service Title','provider-marketplace'); ?></label>
                <input type="text" name="sgpm_title" id="sgpm_title" value="<?php echo esc_attr($title); ?>" required>
            </p>
            <p class="form-row form-row-last">
                <label for="sgpm_price"><?php esc_html_e('Price','provider-marketplace'); ?></label>
                <input type="number" step="0.01" min="0" name="sgpm_price" id="sgpm_price" value="<?php echo esc_attr($price); ?>" required>
            </p>
            <div class="clear"></div>

            <!-- CHANGED: Rich text editor for Short Description -->
            <div class="form-row form-row-wide">
                <label for="sgpm_short"><?php esc_html_e('Short Description','provider-marketplace'); ?></label>
                <div class="sgpm-editor-wrap">
                    <?php
                    \wp_editor(
                        $short,
                        'sgpm_short', // editor ID
                        [
                            'textarea_name' => 'sgpm_short',
                            'editor_height' => 160,
                            'media_buttons' => false,
                            'teeny'         => true,
                            'quicktags'     => true, // allow Text tab
                            'tinymce'       => [
                                'menubar'   => false,
                                'toolbar1'  => 'bold,italic,underline,|,bullist,numlist,|,link,unlink,|,undo,redo,|,removeformat',
                                'toolbar2'  => '',
                                'paste_as_text' => true,
                            ],
                        ]
                    );
                    ?>
                </div>
            </div>

            <!-- CHANGED: Rich text editor for Full Description -->
            <div class="form-row form-row-wide">
                <label for="sgpm_desc"><?php esc_html_e('Full Description','provider-marketplace'); ?></label>
                <div class="sgpm-editor-wrap">
                    <?php
                    \wp_editor(
                        $desc,
                        'sgpm_desc', // editor ID
                        [
                            'textarea_name' => 'sgpm_desc',
                            'editor_height' => 260,
                            'media_buttons' => true,   // allow media if desired for long desc
                            'quicktags'     => true,
                            'tinymce'       => [
                                'menubar'   => false,
                                'toolbar1'  => 'formatselect,bold,italic,underline,|,bullist,numlist,blockquote,|,alignleft,aligncenter,alignright,|,link,unlink,|,undo,redo,|,removeformat',
                                'toolbar2'  => '',
                            ],
                        ]
                    );
                    ?>
                </div>
            </div>

            <!-- Categories UI -->
            <div class="form-row form-row-wide">
                <label for="sgpm_cat_select"><?php esc_html_e('Categories','provider-marketplace'); ?></label>
                <div class="sgpm-cat-ui" style="border:1px solid #e5e5e5;border-radius:8px;padding:10px;">
                    <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                        <select id="sgpm_cat_select" style="min-width:260px;max-width:100%;">
                            <option value=""><?php esc_html_e('— Select a category —','provider-marketplace'); ?></option>
                            <?php echo $options_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </select>
                        <input type="hidden" id="sgpm_cat_ids" name="sgpm_cat_ids" value="<?php echo esc_attr(implode(',', array_map('intval', $selected_cat_ids))); ?>">
                    </div>
                    <div id="sgpm_cat_chips" class="sgpm-cat-chips" style="margin-top:.5rem; display:flex; flex-wrap:wrap; gap:6px;"></div>
                </div>
                <style>
                    .sgpm-chip{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border:1px solid #cfe0ff;border-radius:999px;background:#f0f6ff;color:#0a3069;font-size:12px;line-height:1}
                    .sgpm-chip .sgpm-chip-x{background:none;border:none;cursor:pointer;font-size:14px;line-height:1;padding:0 2px;color:#0a3069}
                    .sgpm-chip .sgpm-chip-x:hover{opacity:.7}
                    /* small quality-of-life for editors */
                    .sgpm-editor-wrap .wp-editor-wrap{max-width:100%;}
                </style>
                <script>
                (function(){
                    const allCats = <?php echo wp_json_encode($term_map_for_js, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?>;
                    const select   = document.getElementById('sgpm_cat_select');
                    const chips    = document.getElementById('sgpm_cat_chips');
                    const hidden   = document.getElementById('sgpm_cat_ids');

                    const toIdStr = v => String(parseInt(v,10));
                    const fromHidden = () => (hidden.value ? hidden.value.split(',').filter(Boolean).map(toIdStr) : []);
                    const selected = new Set(fromHidden());

                    function esc(s){return String(s).replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;', "'":'&#039;' }[m]));}
                    function syncHidden(){ hidden.value = Array.from(selected).join(','); }

                    function renderChip(id){
                        if(!allCats[id]) return;
                        if(chips.querySelector('[data-id="'+id+'"]')) return;
                        const el = document.createElement('span');
                        el.className = 'sgpm-chip';
                        el.dataset.id = id;
                        el.innerHTML = '<span class="sgpm-chip-label">'+esc(allCats[id])+'</span><button type="button" class="sgpm-chip-x" aria-label="Remove">×</button>';
                        chips.appendChild(el);
                    }

                    selected.forEach(renderChip);

                    select.addEventListener('change', function(){
                        const val = toIdStr(this.value || '');
                        if(!val || !allCats[val]) { this.value=''; return; }
                        if(!selected.has(val)){
                            selected.add(val);
                            renderChip(val);
                            syncHidden();
                        }
                        this.value='';
                    });

                    chips.addEventListener('click', function(e){
                        if(e.target && e.target.classList.contains('sgpm-chip-x')){
                            const chip = e.target.closest('.sgpm-chip');
                            const id = chip && chip.dataset.id;
                            if(id){
                                selected.delete(id);
                                chip.remove();
                                syncHidden();
                            }
                        }
                    });
                })();
                </script>
            </div>
            <!-- /Categories UI -->

            <p class="form-row form-row-wide">
                <label for="sgpm_image"><?php esc_html_e('Featured Image (optional)','provider-marketplace'); ?></label>
                <input type="file" name="sgpm_image" id="sgpm_image" accept="image/*">
            </p>

            <p>
                <button type="submit" class="button button-primary"><?php echo $editing_post ? esc_html__('Update Service','provider-marketplace') : esc_html__('Create Service','provider-marketplace'); ?></button>
                <?php if ($editing_post): ?>
                    <a class="button" href="<?php echo esc_url(add_query_arg('t','manage', wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES))); ?>"><?php esc_html_e('Cancel','provider-marketplace'); ?></a>
                <?php endif; ?>
            </p>
        </form>
        <?php echo '</div>';
    }

    public function handle_service_submit(){
        if (!is_user_logged_in() || !Helpers::is_account_endpoint(Constants::EP_YOUR_SERVICES)) return;
        if (!isset($_POST[Constants::NONCE_SVC]) || !wp_verify_nonce($_POST[Constants::NONCE_SVC], Constants::NONCE_SVC)) return;
        if (!Helpers::is_provider()) return;

        $uid   = get_current_user_id();
        $title = sanitize_text_field($_POST['sgpm_title'] ?? '');
        $price = floatval($_POST['sgpm_price'] ?? 0);

        // These now come from wp_editor; keep safe
        $short = wp_kses_post($_POST['sgpm_short'] ?? '');
        $desc  = wp_kses_post($_POST['sgpm_desc'] ?? '');

        $edit_id = isset($_POST['sgpm_service_id']) ? absint($_POST['sgpm_service_id']) : 0;

        // Parse category selections (CSV of term IDs)
        $cat_csv = isset($_POST['sgpm_cat_ids']) ? sanitize_text_field($_POST['sgpm_cat_ids']) : '';
        $cat_ids = array_values(array_filter(array_map('intval', explode(',', $cat_csv))));

        if (!$title || $price < 0) {
            wc_add_notice(__('Please provide a valid title and price.','provider-marketplace'), 'error'); return;
        }

        if ($edit_id) {
            if (get_post_field('post_author', $edit_id) != $uid || get_post_type($edit_id) !== 'product') {
                wc_add_notice(__('Invalid service.','provider-marketplace'), 'error'); return;
            }
            $prod = wc_get_product($edit_id);
            if (!$prod) { wc_add_notice(__('Invalid service.','provider-marketplace'), 'error'); return; }
        } else {
            $post_id = wp_insert_post([
                'post_title'   => $title,
                'post_content' => $desc,
                'post_status'  => 'publish', // change to 'pending' if moderation required
                'post_author'  => $uid,
                'post_type'    => 'product',
            ]);
            if (is_wp_error($post_id) || !$post_id) { wc_add_notice(__('Could not create service.','provider-marketplace'), 'error'); return; }
            $prod = wc_get_product($post_id);
            $prod->set_catalog_visibility('visible');
            $prod->set_virtual(true);
            $prod->set_sold_individually(false);
        }

        $prod->set_name($title);
        $prod->set_regular_price($price);
        $prod->set_price($price);
        $prod->set_short_description($short);
        $prod->set_description($desc);

        if (!empty($_FILES['sgpm_image']['name'])) {
            $attach_id = Helpers::handle_image_upload($_FILES['sgpm_image'], $uid);
            if ($attach_id) set_post_thumbnail($prod->get_id(), $attach_id);
        }

        $prod->save();

        // Assign categories (product_cat)
        if (!empty($cat_ids)) {
            $valid_terms = get_terms([
                'taxonomy'   => 'product_cat',
                'hide_empty' => false,
                'include'    => $cat_ids,
                'fields'     => 'ids',
            ]);
            if (!is_wp_error($valid_terms)) {
                wp_set_object_terms($prod->get_id(), array_map('intval', $valid_terms), 'product_cat', false);
            }
        } else {
            wp_set_object_terms($prod->get_id(), [], 'product_cat', false);
        }

        wc_add_notice($edit_id ? __('Service updated.','provider-marketplace') : __('Service created.','provider-marketplace'));
        wp_safe_redirect(add_query_arg('t','manage', wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES)));
        exit;
    }

    /* ---------- Manage view (cards) with OUTSIDE buttons ---------- */

    private function render_services_table(int $uid){
        $q = new \WP_Query([
            'post_type'      => 'product',
            'posts_per_page' => 20,
            'author'         => $uid,
            'post_status'    => ['publish','pending','draft'],
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        // Styles
        ?>
        <style>
            .sgpm-services-list{display:flex;flex-direction:column;gap:3rem;margin-top:10px}
            .sgpm-svc-wrap{position:relative}
            .sgpm-svc-card{
                display:grid;
                grid-template-columns: 260px 1fr;
                background:#fff;
                border:1px solid #e5e5e5;
                border-radius:0px;
                position:relative;
                overflow:visible;
            }
            .sgpm-svc-meta{border-right:1px solid #e5e5e5;background:#fff}
            .sgpm-svc-meta-row{
                display:grid;grid-template-columns:120px 1fr;
                align-items:center;
                padding:14px 16px;
                border-bottom:1px solid #e5e5e5;
            }
            .sgpm-svc-meta-row:last-child{border-bottom:none}
            .sgpm-svc-meta-label{font-size:14px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:#000;}
            .sgpm-svc-meta-val{font-size:15px;font-weight:300;line-height:1.8;color:#000;}
            .sgpm-svc-body{padding:16px 16px 24px 16px}
            .sgpm-svc-title{margin:2px 0 6px 0;font-size:14px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:#000;}
            .sgpm-svc-desc{margin:0;color:#1d1d1f;font-size:15px;line-height:1.9;font-weight:300}
            .sgpm-svc-actions{display:flex;gap:12px;flex-wrap:wrap;z-index:2;align-content:center;align-items:center;margin-top:1.5rem}
            .serviceeditbutton,.servicedeletebutton{
                display:inline-flex;align-items:center;justify-content:center;gap:8px;border-radius:999px;padding:11px 18px!important;
                font-size:14px;font-weight:700;letter-spacing:.13em;text-transform:uppercase;text-decoration:none;cursor:pointer;line-height:1.5!important
            }
            .serviceeditbutton{background:#FE6601;color:#fff;border:none}
            .servicedeletebutton{background:#fff;color:#000;border:1px solid #000;margin-bottom:0!important}
            @media (max-width:800px){
                .sgpm-svc-card{grid-template-columns:1fr}
                .sgpm-svc-meta{border-right:none;border-bottom:1px solid #e5e5e5}
            }
        </style>
        <?php

        if ($q->have_posts()) {
            echo '<div class="sgpm-services-list">';
            while ($q->have_posts()) {
                $q->the_post();
                $pid  = get_the_ID();
                $prod = wc_get_product($pid);

                $price_html = $prod ? $prod->get_price_html() : '';
                $status_obj = get_post_status_object(get_post_status($pid));
                $status_lbl = $status_obj && !empty($status_obj->label) ? $status_obj->label : get_post_status($pid);

                $raw = '';
                if ($prod){
                    $raw = $prod->get_short_description();
                    if (!$raw) { $raw = $prod->get_description(); }
                }
                $desc = wp_trim_words( wp_strip_all_tags( (string)$raw ), 28, '…' );

                $edit_url = add_query_arg(['t'=>'add','service_id'=>$pid], wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES));

                echo '<div class="sgpm-svc-wrap">';

                // Card
                echo '<div class="sgpm-svc-card">';

                // LEFT COLUMN
                echo '<div class="sgpm-svc-meta">';
                    echo '<div class="sgpm-svc-meta-row">';
                        echo '<div class="sgpm-svc-meta-label">'.esc_html__('PRICE','provider-marketplace').'</div>';
                        echo '<div class="sgpm-svc-meta-val">'.($price_html ? wp_kses_post($price_html) : esc_html__('—','provider-marketplace')).'</div>';
                    echo '</div>';
                    echo '<div class="sgpm-svc-meta-row">';
                        echo '<div class="sgpm-svc-meta-label">'.esc_html__('STATUS','provider-marketplace').'</div>';
                        echo '<div class="sgpm-svc-meta-val">'.esc_html($status_lbl).'</div>';
                    echo '</div>';
                echo '</div>';

                // RIGHT COLUMN
                echo '<div class="sgpm-svc-body">';
                    echo '<div class="sgpm-svc-title">'.esc_html(get_the_title()).'</div>';
                    if ($desc){
                        echo '<p class="sgpm-svc-desc">'.esc_html($desc).'</p>';
                    }
                echo '</div>'; // body

                echo '</div>'; // card

                // OUTSIDE actions
                echo '<div class="sgpm-svc-actions">';
                    ?>
                    <form method="post" onsubmit="return confirm('<?php echo esc_js(__('Move to Trash?','provider-marketplace')); ?>');" style="display:inline;margin-bottom:0;">
                        <?php wp_nonce_field(Constants::NONCE_DEL, Constants::NONCE_SAMP_DEL); ?>
                        <?php wp_nonce_field(Constants::NONCE_DEL, Constants::NONCE_DEL); ?>
                        <input type="hidden" name="sgpm_delete_id" value="<?php echo esc_attr($pid); ?>">
                        <input type="hidden" name="t" value="manage">
                        <button type="submit" class="servicedeletebutton"><?php esc_html_e('Delete','provider-marketplace'); ?></button>
                    </form>
                    <?php
                    echo '<a class="serviceeditbutton" href="'.esc_url($edit_url).'">'.esc_html__('Edit Service','provider-marketplace').'</a>';
                echo '</div>'; // actions

                echo '</div>'; // wrap
            }
            echo '</div>';
            wp_reset_postdata();
        } else {
            echo '<p>'.esc_html__('No services yet. Use the Add Service tab to create your first one.','provider-marketplace').'</p>';
        }
    }

    public function handle_service_delete(){
        if (!is_user_logged_in() || !Helpers::is_account_endpoint(Constants::EP_YOUR_SERVICES)) return;
        if (!isset($_POST[Constants::NONCE_DEL]) || !wp_verify_nonce($_POST[Constants::NONCE_DEL], Constants::NONCE_DEL)) return;
        if (!Helpers::is_provider()) return;

        $uid = get_current_user_id();
        $del_id = isset($_POST['sgpm_delete_id']) ? absint($_POST['sgpm_delete_id']) : 0;
        if ($del_id && get_post_type($del_id) === 'product' && (int)get_post_field('post_author', $del_id) === $uid) {
            wp_trash_post($del_id);
            wc_add_notice(__('Service moved to trash.','provider-marketplace'));
        }
        wp_safe_redirect(add_query_arg('t','manage', wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES)));
        exit;
    }

    /* ---------- Samples (upload/list/edit/delete) ---------- */

    private function render_samples_uploader(int $uid){
        echo '<div style="margin:1rem 0;padding:1rem;border:1px solid #e5e5e5;border-radius:0px;">'; ?>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field(Constants::NONCE_SAMP, Constants::NONCE_SAMP); ?>
            <p class="form-row form-row-wide">
                <label for="sgpm_samples_desc"><?php esc_html_e('Description (applies to all files you upload)','provider-marketplace'); ?></label>
                <textarea name="sgpm_samples_desc" id="sgpm_samples_desc" rows="2" placeholder="<?php esc_attr_e('e.g., Portfolio reel, before/after shots, etc.','provider-marketplace'); ?>"></textarea>
            </p>
            <p class="form-row form-row-wide">
                <label for="sgpm_samples"><?php esc_html_e('Select files','provider-marketplace'); ?></label>
                <!-- Accept images, videos, and audio (including .wav) -->
                <input type="file" name="sgpm_samples[]" id="sgpm_samples" multiple accept="image/*,video/*,audio/*,.wav">
            </p>
            <p>
                <input type="hidden" name="t" value="samples">
                <button type="submit" class="button button-primary"><?php esc_html_e('Upload Service Sample','provider-marketplace'); ?></button>
            </p>
        </form>
        <?php echo '</div>';
    }

    private function render_samples_list(int $uid){
        $items = get_posts([
            'post_type'      => 'attachment',
            'posts_per_page' => 50,
            'post_status'    => 'inherit',
            'author'         => $uid,
            'meta_key'       => Constants::SAMPLE_FLAG_META,
            'meta_value'     => 1,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        echo '<h4 class="headeraccound" style="margin-top: 2rem;">'.esc_html__('Your Samples','provider-marketplace').'</h4>';
        if (!$items) { echo '<p>'.esc_html__('No samples uploaded yet.','provider-marketplace').'</p>'; return; }

        echo '<div class="sgpm-samples-grid" style="display:grid; grid-template-columns:repeat(auto-fill,minmax(280px,1fr)); gap:16px;">';
        foreach ($items as $att) {
            $mime = (string)$att->post_mime_type;
            $is_img = strpos($mime, 'image/') === 0;
            $is_vid = strpos($mime, 'video/') === 0;
            $is_aud = strpos($mime, 'audio/') === 0;
            $url = wp_get_attachment_url($att->ID);

            echo '<div class="sgpm-sample" style="border:1px solid #eee;border-radius:8px;padding:10px;">';

            if ($is_img || $is_vid) {
                // Unified 16:9 media box for images & videos
                echo '<div class="sgpm-sample-media" style="aspect-ratio:16/9; overflow:hidden; display:flex; align-items:center; justify-content:center; background:#fafafa;">';
                if ($is_img) {
                    echo wp_get_attachment_image($att->ID, 'medium', false, ['style'=>'max-width:100%;height:auto;']);
                } else { // video
                    echo wp_video_shortcode(['src'=>$url, 'preload'=>'metadata']);
                }
                echo '</div>';
            } elseif ($is_aud) {
                // Audio: NO empty 16:9 box – render only the player and filename
                echo '<div class="sgpm-sample-audio" style="padding:.5rem 0">';
                echo wp_audio_shortcode(['src'=>$url, 'preload'=>'metadata']);
                echo '<div style="font-size:12px;color:#555;margin-top:4px;">'.esc_html(basename(get_attached_file($att->ID))).'</div>';
                echo '</div>';
            } else {
                echo '<div class="sgpm-sample-media" style="padding:.5rem 0">';
                echo '<a href="'.esc_url($url).'">'.esc_html(basename(get_attached_file($att->ID))).'</a>';
                echo '</div>';
            }

            // Description editor
            echo '<form method="post" style="margin-top:.5rem">';
            wp_nonce_field(Constants::NONCE_SAMP_EDIT, Constants::NONCE_SAMP_EDIT);
            echo '<textarea name="sgpm_sample_desc" rows="2" placeholder="'.esc_attr__('Description','provider-marketplace').'">'.esc_textarea($att->post_content ?: $att->post_excerpt).'</textarea>';
            echo '<input type="hidden" name="sgpm_sample_edit_id" value="'.esc_attr($att->ID).'">';
            echo '<input type="hidden" name="t" value="samples">';
            echo '<p style="margin-top:.5rem; display:flex; gap:.5rem; flex-wrap:wrap">';
            echo '<button class="button buttonsavedesc" type="submit">'.esc_html__('Save Description','provider-marketplace').'</button>';
            echo '</p></form>';

            // Delete button
            echo '<form method="post" onsubmit="return confirm(\''.esc_js(__('Delete this sample?','provider-marketplace')).'\');" style="margin-top:.25rem">';
            wp_nonce_field(Constants::NONCE_SAMP_DEL, Constants::NONCE_SAMP_DEL);
            echo '<input type="hidden" name="sgpm_sample_delete_id" value="'.esc_attr($att->ID).'">';
            echo '<input type="hidden" name="t" value="samples">';
            echo '<button class="button button-danger" type="submit">'.esc_html__('Delete','provider-marketplace').'</button>';
            echo '</form>';

            echo '</div>'; // .sgpm-sample
        }
        echo '</div>'; // .sgpm-samples-grid
    }

    public function handle_samples_submit(){
        if (!is_user_logged_in() || !Helpers::is_account_endpoint(Constants::EP_YOUR_SERVICES)) return;
        if (!isset($_POST[Constants::NONCE_SAMP]) || !wp_verify_nonce($_POST[Constants::NONCE_SAMP], Constants::NONCE_SAMP)) return;
        if (!Helpers::is_provider()) return;

        $uid = get_current_user_id();
        $desc = wp_kses_post($_POST['sgpm_samples_desc'] ?? '');
        if (empty($_FILES['sgpm_samples']['name'][0])) {
            wc_add_notice(__('Please choose at least one file.','provider-marketplace'), 'error');
            return;
        }

        $count = 0;
        foreach ($_FILES['sgpm_samples']['name'] as $i => $name) {
            if (!$name) continue;
            $file = [
                'name'     => $_FILES['sgpm_samples']['name'][$i],
                'type'     => $_FILES['sgpm_samples']['type'][$i],
                'tmp_name' => $_FILES['sgpm_samples']['tmp_name'][$i],
                'error'    => $_FILES['sgpm_samples']['error'][$i],
                'size'     => $_FILES['sgpm_samples']['size'][$i],
            ];
            // Only allow image/video/audio
            $ft = wp_check_filetype_and_ext($file['tmp_name'], $file['name']);
            if (!empty($ft['type']) && !preg_match('~^(image|video|audio)/~i', $ft['type'])) {
                continue;
            }

            $attach_id = Helpers::handle_file_upload($file, $uid, $desc);
            if ($attach_id) {
                add_post_meta($attach_id, Constants::SAMPLE_FLAG_META, 1, true);
                $count++;
            }
        }
        if ($count) wc_add_notice(sprintf(_n('%d sample uploaded.','%d samples uploaded.', $count, 'provider-marketplace'), $count));
        wp_safe_redirect(add_query_arg('t','samples', wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES)));
        exit;
    }

    public function handle_sample_delete(){
        if (!is_user_logged_in() || !Helpers::is_account_endpoint(Constants::EP_YOUR_SERVICES)) return;
        if (!isset($_POST[Constants::NONCE_SAMP_DEL]) || !wp_verify_nonce($_POST[Constants::NONCE_SAMP_DEL], Constants::NONCE_SAMP_DEL)) return;
        if (!Helpers::is_provider()) return;

        $uid = get_current_user_id();
        $att_id = isset($_POST['sgpm_sample_delete_id']) ? absint($_POST['sgpm_sample_delete_id']) : 0;
        if ($att_id && get_post_type($att_id) === 'attachment' && (int)get_post_field('post_author', $att_id) === $uid) {
            wp_delete_attachment($att_id, true);
            wc_add_notice(__('Sample deleted.','provider-marketplace'));
        }
        wp_safe_redirect(add_query_arg('t','samples', wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES)));
        exit;
    }

    public function handle_sample_edit(){
        if (!is_user_logged_in() || !Helpers::is_account_endpoint(Constants::EP_YOUR_SERVICES)) return;
        if (!isset($_POST[Constants::NONCE_SAMP_EDIT]) || !wp_verify_nonce($_POST[Constants::NONCE_SAMP_EDIT], Constants::NONCE_SAMP_EDIT)) return;
        if (!Helpers::is_provider()) return;

        $uid = get_current_user_id();
        $att_id = isset($_POST['sgpm_sample_edit_id']) ? absint($_POST['sgpm_sample_edit_id']) : 0;
        $desc   = wp_kses_post($_POST['sgpm_sample_desc'] ?? '');
        if ($att_id && get_post_type($att_id) === 'attachment' && (int)get_post_field('post_author', $att_id) === $uid) {
            wp_update_post(['ID'=>$att_id, 'post_content'=>$desc, 'post_excerpt'=>$desc]);
            wc_add_notice(__('Description saved.','provider-marketplace'));
        }
        wp_safe_redirect(add_query_arg('t','samples', wc_get_account_endpoint_url(Constants::EP_YOUR_SERVICES)));
        exit;
    }
}
