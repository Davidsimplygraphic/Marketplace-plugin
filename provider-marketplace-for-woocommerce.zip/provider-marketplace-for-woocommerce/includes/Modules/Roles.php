<?php
namespace SGPM\Modules;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

class Roles {
    public static function activate(): void {
        self::add_or_update_role();
    }
    public static function init(): void {
        add_action('init', [__CLASS__, 'add_or_update_role']);
    }
    public static function add_or_update_role(): void {
        if (!get_role(Constants::ROLE)) {
            add_role(Constants::ROLE, 'Provider', [
                'read'                      => true,
                'upload_files'              => true,
                'edit_products'             => true,
                'edit_published_products'   => true,
                'publish_products'          => true,
                'delete_products'           => true,
            ]);
        } else {
            $role = get_role(Constants::ROLE);
            foreach (['read','upload_files','edit_products','edit_published_products','publish_products','delete_products'] as $cap) {
                if (!$role->has_cap($cap)) $role->add_cap($cap);
            }
        }
    }
}
