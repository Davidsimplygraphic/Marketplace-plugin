<?php
namespace SGPM\Modules;

use SGPM\Constants;
use SGPM\Helpers;

if (!defined('ABSPATH')) exit;

class Endpoints {

    /**
     * Called on plugin activation.
     * Registers endpoints and flushes rewrite rules once.
     */
    public static function activate(): void {
        self::register_endpoints();
        // Important: only on activation to avoid performance issues.
        flush_rewrite_rules();
    }

    /**
     * Normal bootstrap.
     */
    public static function init(): void {
        add_action('init', [__CLASS__, 'register_endpoints']);
        add_filter('woocommerce_get_query_vars', [__CLASS__, 'wc_query_vars']);
    }

    /**
     * Register rewrite endpoints (global).
     * Note: Rewrite endpoints must be global; access control is handled
     * via Woo query vars + menu + render guards.
     */
    public static function register_endpoints(): void {
        add_rewrite_endpoint(Constants::EP_PROVIDER_DETAILS, EP_ROOT | EP_PAGES);
        add_rewrite_endpoint(Constants::EP_YOUR_SERVICES,    EP_ROOT | EP_PAGES);
        add_rewrite_endpoint(Constants::EP_ORDER_PORTAL,     EP_ROOT | EP_PAGES);

        // We still register Withdrawals as a rewrite endpoint so links
        // won’t 404 when providers use them. Visibility is controlled
        // in wc_query_vars() + UI guards.
        add_rewrite_endpoint(Constants::EP_WITHDRAWALS,      EP_ROOT | EP_PAGES);
    }

    /**
     * Control which endpoints WooCommerce recognizes on My Account.
     * Here we expose WITHDRAWALS only for logged-in providers.
     */
    public static function wc_query_vars($vars){
        // Always expose these
        $vars[ Constants::EP_PROVIDER_DETAILS ] = Constants::EP_PROVIDER_DETAILS;
        $vars[ Constants::EP_YOUR_SERVICES ]    = Constants::EP_YOUR_SERVICES;
        $vars[ Constants::EP_ORDER_PORTAL ]     = Constants::EP_ORDER_PORTAL;

        // Withdrawals: providers only
        if (is_user_logged_in() && function_exists('wp_get_current_user')) {
            // Use the shared helper so logic stays consistent across the codebase
            if (class_exists('\SGPM\Helpers') && Helpers::is_provider()) {
                $vars[ Constants::EP_WITHDRAWALS ] = Constants::EP_WITHDRAWALS;
            } else {
                // Ensure customers do not accidentally see or resolve this endpoint
                if (isset($vars[ Constants::EP_WITHDRAWALS ])) {
                    unset($vars[ Constants::EP_WITHDRAWALS ]);
                }
            }
        } else {
            // Logged-out users should not resolve it either
            if (isset($vars[ Constants::EP_WITHDRAWALS ])) {
                unset($vars[ Constants::EP_WITHDRAWALS ]);
            }
        }

        return $vars;
    }
}
