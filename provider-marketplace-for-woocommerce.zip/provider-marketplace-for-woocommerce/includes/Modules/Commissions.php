<?php
namespace SGPM\Modules;

use SGPM\Constants;

if (!defined('ABSPATH')) exit;

class Commissions {
    public function init(): void {
        add_action('woocommerce_checkout_create_order_line_item', [$this,'attach_provider_to_item'], 10, 4);
        add_action('woocommerce_order_status_processing', [$this,'calculate_commissions_for_order']);
        add_action('woocommerce_order_status_completed',  [$this,'calculate_commissions_for_order']);
    }

    public function attach_provider_to_item($item, $cart_item_key, $values, $order) {
        $product = $item->get_product();
        if (!$product) return;
        $author_id = (int)get_post_field('post_author', $product->get_id());
        if ($author_id > 0) {
            $item->add_meta_data('_provider_user_id', $author_id, true);
            $item->add_meta_data('_provider_commission_rate', Constants::COMMISSION_RATE, true);
        }
    }

    public function calculate_commissions_for_order($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        foreach ($order->get_items('line_item') as $item) {
            $provider_id = (int)$item->get_meta('_provider_user_id', true);
            if ($provider_id <= 0) continue;
            if ($item->get_meta('_provider_earnings', true) !== '') continue;

            $rate = (float)($item->get_meta('_provider_commission_rate', true) ?: Constants::COMMISSION_RATE);
            $line_total = (float)$item->get_total(); // ex tax
            $provider_amount = round($line_total * $rate, wc_get_price_decimals());
            $admin_commission = $line_total - $provider_amount;

            $item->add_meta_data('_provider_earnings', $provider_amount, true);
            $item->add_meta_data('_admin_commission',  $admin_commission, true);
            $item->save();
        }
    }
}
